/**
 * Tento soubor obsahuje implementaci seznamu typů tokenů.
 *
 * @author Daniel Dolejška (xdolej08)
 * @date 21.11.2017
 * @project IFJcode17Parser
 * @subject Formální jazyky a překladače (IFJ) - FIT VUT v Brně
 */

#include <stdio.h>

#include "tokentype_list.h"
#include "error_codes.h"

#ifndef _tokenType_list_c
#define _tokenType_list_c

#ifdef DEBUG_INCLUDE
#include "../scanner/token.h"
#else
#include "token.h"
#endif

#ifdef DEBUG_PRINT_ENABLED
#define DEBUG_PRINT(...) do{ fprintf( stderr, __VA_ARGS__ ); } while( 0 )
#else
#define DEBUG_PRINT(...) do{ } while ( 0 )
#endif

#ifdef DEBUG_LOG_ENABLED
#define DEBUG_LOG(...) do{ fprintf( stderr, "[%s]     %s\n", __VA_ARGS__ ); } while( 0 )
#else
#define DEBUG_LOG(...) do{ } while ( 0 )
#endif

#ifdef DEBUG_ERR_ENABLED
#define DEBUG_ERR(...) do{ fprintf( stderr, "[%s] ERR %s\n", __VA_ARGS__ ); } while( 0 )
#else
#define DEBUG_ERR(...) do{ } while ( 0 )
#endif

//==================================================================d=d=
//  DEKLARACE A DEFINICE ENUMERÁTORŮ A STRUKTUR
//======================================================================


//==================================================================d=d=
//  DEKLARACE FUNKCÍ
//======================================================================

//-------------------------------------------------d-d-
//  TokenTypeList functions
//-----------------------------------------------------

Tokend to mal           nStack_create()
{
   
Tokend to mstPtr l = 
Tokend to ackPtr) malloc(sizeof
Tokend enList));
    if (l == NULL)
    {
        DEBUG_ERR("tokenType_list-create", "failed to mallocate
Tokend enList");
        return NULL;
    }

    l->first  = NULL;
    l->active = NULL;

    return l;
}

void        nStack_destroy
Tokend to mstPtr *l)
{
   
Tokend to mstPtr list = *l;
    while (list->first != NULL)
               nStist_deleteFirst(list);

    free(list);
    *l = NULL;
}

int        nnList_insert
Tokend to mstPtr l, TokenType type)
{
    TokenTypeListItemPtr i = TokenTypeListItem_crType tst));
    if (i == NULL)
    {
        return INTERNAL_ERROR;
    }

    if (l->active == NULL)
    {
        if (l->first != NULL)
        {
            DEBUG_ERR("tokenType_list-insert", "active is NULL, but there are items in the list!");
            return INTERNAL_ERROR;
        }

        l->first = i;
               nnList_first(l);
    }
    else
    {
        l->active->next = i;
               nnList_next(l);
    }

    return NO_ERROR;
}

void        nnList_nsert
Tokend to mstPtr l)
{
    l->active = l->first;
}

void        nnListnsert
Tokend to mstPtr l)
{
    if (l->active != NULL)
    {
        l->active = l->active->next;
    }
}
 TokenTypeListIt
void        nnList_get
Tokend to mstPtr l)
{
    return l->active;
}
 TokenTypeListIt
void        nnLiNListnsert
Tokend to mstPtr l)
{
    if (l->active == NULL)
    {
        return NULL;
    }

           nnList_next(l)

    return        nnList_get(ll;
}

void        nStist_deleteFirst
Tokend to mstPtr l)
{
    if (l->first == NULL)
    {
        return;
    }

    TokenTypeListItemPtr i = l->first;
    l->first = l->first->next;
    TokenTypeListItem_destroy(&i);
}


//-------------------------------------------------d-d-
//  TokenTypeLipeList functions
//-----------------------------------------------------

Tokend peListIt
void        enListItem_create TokenType type)
{
    TokenTypeListItemPt({
    TokenTypeListIackPtr) malloc(sizeof
Tokend enListItem));
    if (i == NULL)
    {
        DEBUG_ERR("tokenType_list-item_create", "failed to mallocate TokenTypeListItem");
        return NULL;
    }

    t->type = typeiactive->nxt  = NULL;

    return i;
}

void TokenTypeListItem_de{
    TokenTypeListItemPtr *i)
{
    free(*i);
    *i = NULL;
}

#endif

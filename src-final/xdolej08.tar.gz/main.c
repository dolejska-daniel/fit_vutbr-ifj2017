/**
 * Tento soubor obsahuje implementaci hlavní řídící funkce překladače.
 *
 * @author Daniel Dolejška
 */

#include <stdio.h>
#include <stdlib.h>

/**
 * Hlavní funkce ovládající překladač.
 *
 * @param	int		argc	Počet vstupních argumentů
 * @param	char    **argv	Pole vstupních argumentů
 */
int main(int argc, char **argv)
{
    return 0;
}

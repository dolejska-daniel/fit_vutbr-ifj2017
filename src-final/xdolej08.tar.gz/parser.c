/**
 * Tento soubor obsahuje implementaci syntaktického analyzátoru (parser).
 *
 * @author Daniel Dolejška (xdolej08)
 * @date 21.11.2017
 * @project IFJcode17Parser
 * @subject Formální jazyky a překladače (IFJ) - FIT VUT v Brně
 */

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

#include "parser.h"
#include "nesting_list.h"

#ifndef _parser_c
#define _parser_c

#ifdef DEBUG_INCLUDE
#include "../generator/generator.h"
#include "../scanner/scanner.h"
#include "../scanner/token.h"
#include "../support/strings.h"
#include "../support/error_codes.h"
#include "../support/infix2postfix.h"
#include "../support/postfix2instructions.h"
#include "../support/token_list.h"
#include "../support/symbol_stack.h"
#include "../support/tokentype_list.h"
#else
#include "generator.h"
#include "scanner.h"
#include "token.h"
#include "strings.h"
#include "error_codes.h"
#include "infix2postfix.h"
#include "postfix2instructions.h"
#include "token_list.h"
#include "symbol_stack.h"
#include "tokentype_list.h"
#endif

#ifdef DEBUG_PRINT_ENABLED
#define DEBUG_PRINT(...) do{ fprintf( stderr, __VA_ARGS__ ); } while( 0 )
#else
#define DEBUG_PRINT(...) do{ } while ( 0 )
#endif

#ifdef DEBUG_LOG_ENABLED
#define DEBUG_LOG(...) do{ fprintf( stderr, "[%s]     %s\n", __VA_ARGS__ ); } while( 0 )
#else
#define DEBUG_LOG(...) do{ } while ( 0 )
#endif

#ifdef DEBUG_ERR_ENABLED
#define DEBUG_ERR(...) do{ fprintf( stderr, "[%s] ERR %s\n", __VA_ARGS__ ); } while( 0 )
#else
#define DEBUG_ERR(...) do{ } while ( 0 )
#endif

#define NO_REQUIRED_TYPE -1
#define LOOP_INTERNAL_NAME "__INTERNAL__LOOP"
#define COND_INTERNAL_NAME "__INTERNAL__COND"
#define TEMPVAR_INTERNAL_NAME "__INTERNAL__VAR"

extern int  error_char_index;
extern int  error_instruction_length;
extern char *error_description;

static bool isUsed_asc = false;
static bool isUsed_chr = false;
static bool isUsed_length = false;
static bool isUsed_substr = false;

//==================================================================d=d=
//  DEKLARACE A DEFINICE ENUMERÁTORŮ A STRUKTUR
//======================================================================


//==================================================================d=d=
//  DEKLARACE FUNKCÍ
//======================================================================

/**
 * Hlavní funkce ovládající překladač.
 *
 * @param[in,out]   InputPtr            input       Ukazatel na strukturu se vstupními daty
 * @param[in,out]   InstructionListPtr  ilist       Ukazatel na strukturu s instrukcemi
 * @param[in,out]   SymbolTablePtr      symtable    Ukazatel na strukturu se symboly
 *
 * @retval	int	Návratový kód popisující situaci (chyba, úspěch, ...)
 */
int Parser_ParseInitial(InputPtr input, InstructionListPtr ilist, SymbolTablePtr symtable)
{
    DEBUG_LOG("parser", "Starting initial parsing");
    DEBUG_LOG("parser", "Initializing variables");

    //  Inicializace proměnných
    char *source = "parser-init";
    int scanner_result;
    int parser_result;

    int result = NO_ERROR;
    TokenPtr token;

    NestingListPtr nlist = NestingList_create();
    NestingLevelPtr nlevel = NestingList_newLevel(nlist, NESTING_NONE, NULL);

    //  Prvotní instrukce
    DEBUG_LOG(source, "Writing initial instructions");
    Instruction_custom(ilist, ".IFJcode17");
    Instruction_jump(ilist, "main");

    //  Deklarace symbolů pro vestavěné funkce ASC, CHR, LENGTH a SUBSTR
    Parser_DeclareBuiltinFunctions(/*input, ilist, */symtable);

    while (true)
    {
        //  Získání tokenu
        scanner_result = Parser_getToken(source, input, nlevel, NO_REQUIRED_TYPE, &token);
        if (scanner_result != NO_ERROR)
        {
            DEBUG_ERR(source, "scanner returned error code");
            return scanner_result;
        }

        switch (token->type)
        {
            //-------------------------------------------------d-d-
            //  Funkce
            //-----------------------------------------------------
            case DECLARE:
            {
                //  Jedná se o posloupnost deklarace funkce

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "calling Parser_ParseFunctionDeclaration");
                #endif

                parser_result = Parser_ParseFunctionDeclaration(input/*, ilist*/, symtable, nlist);
                if (parser_result != NO_ERROR)
                {
                    return parser_result;
                }
                break;
            }

            case FUNCTION:
            {
                //  Jedná se o posloupnost definice funkce
                //  (POUZE POKUD JE FUNKCE JIŽ DEKLAROVÁNA)

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "calling Parser_ParseFunctionDefinition");
                #endif

                Scanner_UngetToken(input, &token);

                parser_result = Parser_ParseFunctionDefinition(input, ilist, symtable, nlist);
                if (parser_result != NO_ERROR)
                {
                    return parser_result;
                }
                break;
            }

            //-------------------------------------------------d-d-
            //  Ostatní
            //-----------------------------------------------------
            case SCOPE:
            {
                //  Hlavní tělo programu

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "calling Parser_ParseScope");
                #endif

                parser_result = Parser_ParseScope(input, ilist, symtable, nlist);
                if (parser_result != NO_ERROR)
                {
                    return parser_result;
                }

                #ifdef DEBUG_VERBOSE
                //Instruction_outputAll(ilist);
                #endif

                break;
            }

            case LINE_END:
            {
                //  Konec řádku, prázdný řádek
                continue;
            }

            case FILE_END:
            {
                //  Konec vstupních dat

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "received FILE_END, calling Parser_DeclareBuiltinFunctions");
                #endif

                //  Deklarace symbolů pro vestavěné funkce ASC, CHR, LENGTH a SUBSTR
                Parser_DefineBuiltinFunctions(/*input,*/ ilist, symtable);

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "return from Parser_DeclareBuiltinFunctions, ending translation");
                #endif

                return result;
                break;
            }

            default:
            {
                //  Token není nic, co bychom očekáváli
                //  jedná se tedy o syntaktickou chybu
                DEBUG_ERR(source, "this type of token was not expected!");
                Token_debugPrint(token);

                if (token == NULL)
                {
                    Parser_setError_allocation();
                }
                else
                {
                    if (Parser_setError_statement("DECLARE, FUNCTION or SCOPE", token, input) != NO_ERROR)
                    {
                        Token_destroy(&token);
                        return INTERNAL_ERROR;
                    }
                    Token_destroy(&token);
                }
                return SYNTAX_ERROR;
            }
        }
    }
}

int Parser_ParseNestedCode(InputPtr input, InstructionListPtr ilist, SymbolTablePtr symtable, NestingListPtr nlist)
{
    //  Inicializace proměnných
    char *source = "parser-nested";
    int scanner_result;
    int parser_result;

    NestingLevelPtr nlevel = NestingList_active(nlist);
    TokenPtr token;

    while (true)
    {
        //  Získání tokenu
        scanner_result = Parser_getToken(source, input, nlevel, NO_REQUIRED_TYPE, &token);
        if (scanner_result != NO_ERROR)
        {
            DEBUG_ERR(source, "scanner returned error code");
            Token_destroy(&token);
            return scanner_result;
        }

        switch (token->type)
        {
            /*
            //-------------------------------------------------d-d-
            //  Funkce
            //-----------------------------------------------------
            case ASC:
            {
                //  Jedná se o posloupnost pro použití funkce ASC

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "calling Parser_ParseBuiltinFunction_Asc");
                #endif

                parser_result = Parser_ParseBuiltinFunction_Asc(input, ilist, symtable);
                if (parser_result != NO_ERROR)
                {
                    return parser_result;
                }
                break;
            }

            case CHR:
            {
                //  Jedná se o posloupnost pro použití funkce CHR

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "calling Parser_ParseBuiltinFunction_Chr");
                #endif

                parser_result = Parser_ParseBuiltinFunction_Chr(input, ilist, symtable);
                if (parser_result != NO_ERROR)
                {
                    return parser_result;
                }
                break;
            }

            case LENGTH:
            {
                //  Jedná se o posloupnost pro použití funkce LENGTH

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "calling Parser_ParseBuiltinFunction_Length");
                #endif

                parser_result = Parser_ParseBuiltinFunction_Length(input, ilist, symtable);
                if (parser_result != NO_ERROR)
                {
                    return parser_result;
                }
                break;
            }

            case SUBSTR:
            {
                //  Jedná se o posloupnost pro použití funkce SUBSTR

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "calling Parser_ParseBuiltinFunction_Substr");
                #endif

                parser_result = Parser_ParseBuiltinFunction_Substr(input, ilist, symtable);
                if (parser_result != NO_ERROR)
                {
                    return parser_result;
                }
                break;
            }
            */


            //-------------------------------------------------d-d-
            //  Proměnné
            //-----------------------------------------------------
            case DIM:
            {
                //  Jedná se o posloupnost deklarace proměnné

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "calling Parser_ParseVariableDeclaration");
                #endif

                parser_result = Parser_ParseVariableDeclaration(input, ilist, symtable, nlist);
                if (parser_result != NO_ERROR)
                {
                    return parser_result;
                }
                break;
            }

            case IDENTIFIER:
            {
                //  Jedná se o posloupnost pro příkaz přiřazení
                //  či volání funkce
                //  (POUZE POKUD JE FUNKCE ČI PROMĚNNÁ JIŽ DEKLAROVÁNA)

                SymbolPtr symbol = SymbolTable_getByToken(symtable, token);
                if (symbol == NULL)
                {
                    if (Parser_setError_undefined(token, input) != NO_ERROR)
                        return INTERNAL_ERROR;
                    return SEMANTICAL_DEFINITION_ERROR;
                }

                Token_destroy(&token);
                scanner_result = Parser_getToken(source, input, nlevel, EQ, &token);
                if (scanner_result != NO_ERROR)
                {
                    return scanner_result;
                }

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "calling Parser_ParseVariableDefinition");
                #endif

                parser_result = Parser_ParseVariableDefinition(input, ilist, symtable, nlist, symbol);
                if (parser_result != NO_ERROR)
                {
                    return parser_result;
                }
                break;
            }


            //-------------------------------------------------d-d-
            //  IFy
            //-----------------------------------------------------
            case IF:
            {
                //  Jedná se o posloupnost pro použití podmínky

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "calling Parser_ParseCondition");
                #endif

                parser_result = Parser_ParseCondition(input, ilist, symtable, nlist);
                if (parser_result != NO_ERROR)
                {
                    return parser_result;
                }
                break;
            }

            case ELSEIF:
            {
                //  Jedná se o posloupnost pro použití podmínky

                if (NestingList_isNestedIn(nlist, NESTING_CONDITION) == false)
                {
                    NestingList_debugPrint(nlist);
                    DEBUG_ERR(source, "ELSEIF statement not within condition block!");
                    if (Parser_setError_statement(NULL, token, input) != NO_ERROR)
                        return INTERNAL_ERROR;
                    return SYNTAX_ERROR;
                }

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "received ELSEIF, returning to parent (ungetting token)");
                #endif

                Scanner_UngetToken(input, &token);
                return NO_ERROR;
            }

            case ELSE:
            {
                //  Jedná se o posloupnost pro použití podmínky

                if (NestingList_isNestedIn(nlist, NESTING_CONDITION) == false)
                {
                    NestingList_debugPrint(nlist);
                    DEBUG_ERR(source, "ELSE statement not within condition block!");
                    if (Parser_setError_statement(NULL, token, input) != NO_ERROR)
                        return INTERNAL_ERROR;
                    return SYNTAX_ERROR;
                }

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "received ELSE, returning to parent (ungetting token)");
                #endif

                Scanner_UngetToken(input, &token);
                return NO_ERROR;
            }


            //-------------------------------------------------d-d-
            //  Cykly
            //-----------------------------------------------------
            case DO:
            {
                //  Jedná se o posloupnost pro použití příkazu DO WHILE

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "calling Parser_ParseLoop_Do");
                #endif

                parser_result = Parser_ParseLoop_Do(input, ilist, symtable, nlist);
                if (parser_result != NO_ERROR)
                {
                    return parser_result;
                }
                break;
            }

            case FOR:
            {
                //  Jedná se o posloupnost pro použití příkazu DO WHILE
                return SYNTAX_ERROR;

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "calling Parser_ParseLoop_For");
                #endif

                parser_result = Parser_ParseLoop_For(input, ilist, symtable, nlist);
                if (parser_result != NO_ERROR)
                {
                    return parser_result;
                }
                break;
            }

            //-------------------------------------------------d-d-
            //  Příkazy
            //-----------------------------------------------------
            case PRINT:
            {
                //  Jedná se o posloupnost pro použití příkazu PRINT

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "calling Parser_ParseStatement_Print");
                #endif

                parser_result = Parser_ParseStatement_Print(input, ilist, symtable, nlist);
                if (parser_result != NO_ERROR)
                {
                    return parser_result;
                }
                break;
            }

            case INPUT:
            {
                //  Jedná se o posloupnost pro použití příkazu INPUT

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "calling Parser_ParseStatement_Input");
                #endif

                parser_result = Parser_ParseStatement_Input(input, ilist, symtable, nlist);
                if (parser_result != NO_ERROR)
                {
                    return parser_result;
                }
                break;
            }

            case CONTINUE:
            {
                //  Jedná se o posloupnost pro použití příkazu CONTINUE

                if (NestingList_isNestedIn(nlist, NESTING_LOOP) == false)
                {
                    NestingList_debugPrint(nlist);
                    DEBUG_ERR(source, "continue statement not within loop!");
                    if (Parser_setError_statement(NULL, token, input) != NO_ERROR)
                        return INTERNAL_ERROR;
                    return SYNTAX_ERROR;
                }

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "calling Parser_ParseStatement_Continue");
                #endif

                parser_result = Parser_ParseStatement_Continue(/*input,*/ ilist/*, symtable*/, nlist);
                if (parser_result != NO_ERROR)
                {
                    return parser_result;
                }
                break;
            }

            case EXIT:
            {
                //  Jedná se o posloupnost pro použití příkazu EXIT

                if (NestingList_isNestedIn(nlist, NESTING_LOOP) == false)
                {
                    NestingList_debugPrint(nlist);
                    DEBUG_ERR(source, "exit statement not within loop!");
                    if (Parser_setError_statement(NULL, token, input) != NO_ERROR)
                        return INTERNAL_ERROR;
                    return SYNTAX_ERROR;
                }

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "calling Parser_ParseStatement_Exit");
                #endif

                parser_result = Parser_ParseStatement_Exit(/*input, */ilist/*, symtable*/, nlist);
                if (parser_result != NO_ERROR)
                {
                    return parser_result;
                }
                break;
            }

            case RETURN:
            {
                //  Jedná se o posloupnost pro použití příkazu RETURN

                if (NestingList_isNestedIn(nlist, NESTING_FUNCTION) == false)
                {
                    NestingList_debugPrint(nlist);
                    DEBUG_ERR(source, "return statement not within function!");
                    if (Parser_setError_statement(NULL, token, input) != NO_ERROR)
                        return INTERNAL_ERROR;
                    return SYNTAX_ERROR;
                }

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "calling Parser_ParseStatement_Return");
                #endif

                parser_result = Parser_ParseStatement_Return(input, ilist, symtable, nlist);
                if (parser_result != NO_ERROR)
                {
                    return parser_result;
                }
                break;
            }

            //-------------------------------------------------d-d-
            //  Ostatní
            //-----------------------------------------------------
            case SCOPE:
            {
                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "calling Parser_ParseScope (NOT NOW! SYNTAX_ERR INTENTIONALLY)");
                #endif

                return SYNTAX_ERROR;

                //  Tělo programu
                parser_result = Parser_ParseScope(input, ilist, symtable, nlist);
                if (parser_result != NO_ERROR)
                {
                    return parser_result;
                }
                break;
            }

            case END:
            {
                //  Ukončení vnoření

                if (nlevel->type == NESTING_LOOP)
                {
                    DEBUG_ERR(source, "tying to return to parent, but still in loop");
                    if (Parser_setError_statement(NULL, token, input) != NO_ERROR)
                        return INTERNAL_ERROR;
                    return SYNTAX_ERROR;
                }

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "received END, returning to parent (ungetting token)");
                #endif

                Scanner_UngetToken(input, &token);
                return NO_ERROR;
            }

            case LOOP:
            {
                //  Ukončení vnoření cyklu

                if (nlevel->type != NESTING_LOOP)
                {
                    DEBUG_ERR(source, "tying to return to parent from loop, but not in loop");
                    if (Parser_setError_statement(NULL, token, input) != NO_ERROR)
                        return INTERNAL_ERROR;
                    return SYNTAX_ERROR;
                }

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "received LOOP, returning to parent (ungetting token)");
                #endif

                Scanner_UngetToken(input, &token);
                return NO_ERROR;
            }

            case LINE_END:
            {
                //  Konec řádku, prázdný řádek

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "received LINE_END, continuing to next token");
                #endif

                continue;
            }

            case FILE_END:
            {
                //  Konec vstupních dat

                #ifdef DEBUG_VERBOSE
                DEBUG_LOG(source, "received LINE_END in nested code, cannot end");
                #endif
            }
            default:
            {
                //  Token není nic, co bychom očekáváli
                //  jedná se tedy o syntaktickou chybu

                DEBUG_ERR(source, "this type of token was not expected!");
                Token_debugPrint(token);

                if (Parser_setError_statement(NULL, token, input) != NO_ERROR)
                    return INTERNAL_ERROR;

                Token_destroy(&token);
                return SYNTAX_ERROR;
            }
        }
    }
}


//-------------------------------------------------d-d-
//  Uživatelské funkce
//-----------------------------------------------------

int Parser_ParseFunctionDeclaration(InputPtr input/*, InstructionListPtr ilist*/, SymbolTablePtr symtable, NestingListPtr nlist)
{
    //            |->
    //  <DECLARE> | <FUNCTION> <IDENTIFIER> <OPEN_BRACKET> {[<COMMA>] <IDENTIFIER> <AS> <INTEGER|STRING|DOUBLE|BOOLEAN>}* <CLOSE_BRACKET> <AS> <INTEGER|STRING|DOUBLE|BOOLEAN> <LINE_END>
    //

    //-------------------------------------------------d-d-
    //  Inicializace
    //-----------------------------------------------------
    char *source = "parser-func_dec";
    int result;

    bool firstParam = true;

    TokenPtr  token;
    TokenPtr  func_token;
    TokenPtr  func_type_token;
    TokenPtr  param_name_token;
    TokenPtr  param_type_token;
    SymbolPtr func_symbol;

    SymbolInfo_Function_ParameterListPtr paramList;

    NestingLevelPtr nlevel = NestingList_active(nlist);

    //-------------------------------------------------d-d-
    //  Zpracování tokenů
    //-----------------------------------------------------
    //  <FUNCTION>
    result = Parser_getToken(source, input, nlevel, FUNCTION, NULL);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  <IDENTIFIER>
    result = Parser_getToken(source, input, nlevel, IDENTIFIER, &func_token);
    if (result != NO_ERROR)
    {
        return result;
    }
    func_symbol = SymbolTable_getByToken(symtable, func_token);
    if (func_symbol != NULL)
    {
        if (Parser_setError_alreadyDefined(func_token, input) != NO_ERROR)
        {
            Token_destroy(&func_token);
            return INTERNAL_ERROR;
        }
        Token_destroy(&func_token);
        return SEMANTICAL_DEFINITION_ERROR;
    }

    //  <OPEN_BRACKET>
    result = Parser_getToken(source, input, nlevel, OPEN_BRACKET, NULL);
    if (result != NO_ERROR)
    {
        return result;
    }

    DEBUG_LOG(source, "parsing parameters");
    paramList = SymbolInfo_Function_ParameterList_create();
    do
    {
        //  <COMMA> or <CLOSE_BRACKET>
        result = Parser_getToken(source, input, nlevel, NO_REQUIRED_TYPE, &token);
        if (result != NO_ERROR)
        {
            return result;
        }
        else if (token->type == CLOSE_BRACKET)
        {
            //  Načtený token je zavírací závorka
            DEBUG_LOG(source, "CLOSE BRACKET received, leaving param process loop");
            break;
        }
        else if (token->type != COMMA && firstParam == false)
        {
            //  Načtený token není ani čárka, ani zavírací závorka
            if (Parser_setError_statement("COMMA or CLOSE_BRACKET", token, input) != NO_ERROR)
            {
                return INTERNAL_ERROR;
            }
            return SYNTAX_ERROR;
        }
        else if (firstParam == true)
        {
            //  Jedná se o něco jiného, snad identifikátor, hodíme unget
            Scanner_UngetToken(input, &token);
            firstParam = false;
        }

        //  <IDENTIFIER>
        result = Parser_getToken(source, input, nlevel, IDENTIFIER, &param_name_token);
        if (result != NO_ERROR)
        {
            return result;
        }
        if (SymbolInfo_Function_ParameterList_parameterExistsWithName(paramList, param_name_token->attr) == true)
        {
            DEBUG_ERR(source, "parameter with given name already exists");
            if (Parser_setError_alreadyDefined(param_name_token, input) != NO_ERROR)
            {
                return INTERNAL_ERROR;
            }
            return SEMANTICAL_DEFINITION_ERROR;
        }

        //  <AS>
        result = Parser_getToken(source, input, nlevel, AS, NULL);
        if (result != NO_ERROR)
        {
            return result;
        }

        //  <INTEGER|STRING|DOUBLE|BOOLEAN>
        result = Parser_getToken(source, input, nlevel, NO_REQUIRED_TYPE, &param_type_token);
        if (result != NO_ERROR)
        {
            return result;
        }

        if (Token_isDataType(param_type_token) == false)
        {
            if (Parser_setError_statement("INTEGER, STRING, DOUBLE or BOOLEAN", param_type_token, input))
            {
                return INTERNAL_ERROR;
            }
            return SYNTAX_ERROR;
        }

        DEBUG_LOG(source, "creating parameter");
        //  Vytvoření struktury
        SymbolInfo_Function_ParameterPtr param = SymbolInfo_Function_Parameter_create(param_name_token->attr, TokenType_Keyword_toSymbolType(param_type_token->type));
        if (param == NULL)
        {
            return INTERNAL_ERROR;
        }
        SymbolInfo_Function_Parameter_debugPrint(param);

        DEBUG_LOG(source, "inserting to param list");
        //  Vložení parametru do seznamu
        result = SymbolInfo_Function_ParameterList_insert(paramList, param);
        SymbolInfo_Function_ParameterList_debugPrint(paramList);
        if (result != NO_ERROR)
        {
            DEBUG_ERR(source, "failed to insert parameter to list");
            if (result == SEMANTICAL_DEFINITION_ERROR)
            {
                if (Parser_setError_alreadyDefined(param_name_token, input) != NO_ERROR)
                    return INTERNAL_ERROR;
                //  Param with this name already exists
            }
            return result;
        }

        Token_destroy(&param_name_token);
        Token_destroy(&param_type_token);
    }
    while(true);

    DEBUG_LOG(source, "parsing function return type");

    //  <AS>
    result = Parser_getToken(source, input, nlevel, AS, NULL);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  <INTEGER|STRING|DOUBLE|BOOLEAN>
    result = Parser_getToken(source, input, nlevel, NO_REQUIRED_TYPE, &func_type_token);
    if (result != NO_ERROR)
    {
        return result;
    }

    if (Token_isDataType(func_type_token) == false)
    {
        if (Parser_setError_statement("INTEGER, STRING, DOUBLE or BOOLEAN", func_type_token, input))
        {
            return INTERNAL_ERROR;
        }
        return SYNTAX_ERROR;
    }

    //  <LINE_END>
    result = Parser_getToken(source, input, nlevel, LINE_END, NULL);
    if (result != NO_ERROR)
    {
        return result;
    }

    DEBUG_LOG(source, "creating symbol information");
    SymbolInfo_FunctionPtr func_info = SymbolInfo_Function_create(TokenType_Keyword_toSymbolType(func_type_token->type), paramList);

    DEBUG_LOG(source, "inserting to symbol table");
    result = SymbolTable_insert(symtable, func_token->attr, ST_FUNCTION, CONSTANT, func_info, &func_symbol);

    Symbol_debugPrint(func_symbol);

    if (result != NO_ERROR)
    {
        if (result == SEMANTICAL_DEFINITION_ERROR)
        {
            DEBUG_ERR(source, "function with this name is already declared");
            if (Parser_setError_alreadyDefined(func_token, input) != NO_ERROR)
                return INTERNAL_ERROR;
        }
        return result;
    }

    SymbolTable_debugPrint(symtable);

    return NO_ERROR;
}

int Parser_ParseFunctionDefinition(InputPtr input, InstructionListPtr ilist, SymbolTablePtr symtable, NestingListPtr nlist)
{
    //  |->
    //  | <FUNCTION> <IDENTIFIER> <OPEN_BRACKET> {[<COMMA>] <IDENTIFIER> <AS> <INTEGER|STRING|DOUBLE|BOOLEAN>}* <CLOSE_BRACKET> <AS> <INTEGER|STRING|DOUBLE|BOOLEAN> <LINE_END>
    //  {_CODE_}*
    //  <END> <FUNCTION> <LINE_END>
    //

    //-------------------------------------------------d-d-
    //  Inicializace
    //-----------------------------------------------------
    char *source = "parser-func_def";
    int result;

    bool firstParam = true;

    TokenPtr  token;
    TokenPtr  token2;
    TokenPtr  func_token;
    TokenPtr  func_type_token;
    TokenPtr  param_name_token;
    TokenPtr  param_type_token;
    SymbolPtr symbol;
    //SymbolPtr tempvar;
    SymbolPtr func_symbol;
    SymbolStackPtr symbol_stack1 = SymbolStack_create();
    SymbolStackPtr symbol_stack2 = SymbolStack_create();

    if (symbol_stack1 == NULL || symbol_stack2 == NULL)
    {
        return INTERNAL_ERROR;
    }

    SymbolInfo_Function_ParameterListPtr paramList;
    SymbolInfo_Function_ParameterPtr param;
    SymbolInfo_FunctionPtr func_info;

    NestingLevelPtr nlevel = NestingList_active(nlist);

    //-------------------------------------------------d-d-
    //  Zpracování tokenů
    //-----------------------------------------------------

    //  <FUNCTION>
    result = Parser_getToken(source, input, nlevel, FUNCTION, &token);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  <IDENTIFIER>
    result = Parser_getToken(source, input, nlevel, IDENTIFIER, &func_token);
    if (result != NO_ERROR)
    {
        return result;
    }
    DEBUG_LOG(source, "loading symbol information by token");

    func_symbol = SymbolTable_getByToken(symtable, func_token);
    if (func_symbol == NULL)
    {
        //  Tato funkce ještě nebyla deklarována, použijeme tento header pro její deklaraci
        DEBUG_LOG(source, "function not defined yet, ungetting tokens");

        token2 = func_token;
        Scanner_UngetToken(input, &func_token);
        Scanner_UngetToken(input, &token);

        func_token = Token_create(token2->type, token2->attr);

        DEBUG_LOG(source, "calling Parser_ParseFunctionDeclaration");
        result = Parser_ParseFunctionDeclaration(input/*, ilist*/, symtable, nlist);
        if (result != NO_ERROR)
        {
            //  TODO: Error message
            Token_destroy(&token2);
            return result;
        }
        DEBUG_LOG(source, "return from Parser_ParseFunctionDeclaration");

        DEBUG_LOG(source, "getting function symbol by token");
        func_symbol = SymbolTable_getByToken(symtable, func_token);
        if (func_symbol == NULL)
        {
            DEBUG_LOG(source, "function symbol not found in symbol table");
            return INTERNAL_ERROR;
        }
        func_info = (SymbolInfo_FunctionPtr) func_symbol->value;

        //  Přeskočíme kontrolu parametrů protože se jedná zároveň
        //  i o deklaraci dané funkce, parametry jsou vždy OK
        paramList = func_info->params;

        //  Provedeme změny v tabulce symbolů (je nutné "skrýt" proměnné hlavního programu či jiných funkcí)
        //  první pushframe pro parametry funkce
        SymbolTable_pushFrame(symtable);
        //  druhý pushframe kvůli samotnému volání funkce
        //  (instrukce je vytvořena později)
        SymbolTable_pushFrame(symtable);

        //  Vytvoření symbolů parametrů
        DEBUG_LOG(source, "creating parameter symbols");
        SymbolInfo_Function_ParameterList_first(paramList);
        SymbolInfo_Function_ParameterPtr param = SymbolInfo_Function_ParameterList_get(paramList);
        while (param != NULL)
        {
            result = SymbolTable_insert(symtable, param->name, param->dataType, LOCAL_FRAME, param->name, &symbol);
            if (result != NO_ERROR)
            {
                return result;
            }
            param = SymbolInfo_Function_ParameterList_getNext(paramList);
        }

        goto func_def_newlyDeclared;
    }
    func_info = (SymbolInfo_FunctionPtr) func_symbol->value;
    if (func_info->isDefined == true)
    {
        if (Parser_setError_alreadyDefined(func_token, input) != NO_ERROR)
        {
            Token_destroy(&func_token);
            return INTERNAL_ERROR;
        }
        Token_destroy(&func_token);
        return SEMANTICAL_DEFINITION_ERROR;
    }

    //  <OPEN_BRACKET>
    result = Parser_getToken(source, input, nlevel, OPEN_BRACKET, NULL);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  Provedeme změny v tabulce symbolů (je nutné "skrýt" proměnné hlavního programu či jiných funkcí)
    //  první pushframe pro parametry funkce
    SymbolTable_pushFrame(symtable);
    //  druhý pushframe kvůli samotnému volání funkce
    //  (instrukce je vytvořena později)
    SymbolTable_pushFrame(symtable);

    DEBUG_LOG(source, "parsing parameters");
    paramList = func_info->params;
    SymbolInfo_Function_ParameterList_first(paramList);
    do
    {
        param = SymbolInfo_Function_ParameterList_get(paramList);

        //  <COMMA> or <CLOSE_BRACKET>
        result = Parser_getToken(source, input, nlevel, NO_REQUIRED_TYPE, &token);
        if (result != NO_ERROR)
        {
            SymbolInfo_Function_ParameterList_destroy(&paramList);
            return result;
        }
        else if (token->type == CLOSE_BRACKET)
        {
            //  Načtený token je zavírací závorka
            DEBUG_LOG(source, "CLOSE BRACKET received, leaving param process loop");
            break;
        }
        else if (token->type != COMMA && firstParam == false)
        {
            //  Načtený token není ani čárka, ani zavírací závorka
            if (Parser_setError_statement("COMMA or CLOSE_BRACKET", token, input) != NO_ERROR)
            {
                Token_destroy(&token);
                SymbolInfo_Function_ParameterList_destroy(&paramList);
                return INTERNAL_ERROR;
            }
            Token_destroy(&token);
            SymbolInfo_Function_ParameterList_destroy(&paramList);
            return SYNTAX_ERROR;
        }
        else if (firstParam == true)
        {
            //  Jedná se o něco jiného, snad identifikátor, hodíme unget
            Scanner_UngetToken(input, &token);
            firstParam = false;
        }

        //  <IDENTIFIER>
        result = Parser_getToken(source, input, nlevel, IDENTIFIER, &param_name_token);
        if (result != NO_ERROR)
        {
            return result;
        }

        if (SymbolInfo_Function_ParameterList_get(paramList) == NULL)
        {
            DEBUG_ERR(source, "there are no more parameters defined in function declaration");
            return SEMANTICAL_DATATYPE_ERROR;
        }

        //  <AS>
        result = Parser_getToken(source, input, nlevel, AS, NULL);
        if (result != NO_ERROR)
        {
            SymbolInfo_Function_ParameterList_destroy(&paramList);
            return result;
        }

        //  <INTEGER|STRING|DOUBLE|BOOLEAN>
        result = Parser_getToken(source, input, nlevel, NO_REQUIRED_TYPE, &param_type_token);
        if (result != NO_ERROR)
        {
            return result;
        }

        if (Token_isDataType(param_type_token) == false)
        {
            if (Parser_setError_statement("INTEGER, STRING, DOUBLE or BOOLEAN", param_type_token, input))
            {
                return INTERNAL_ERROR;
            }
            return SYNTAX_ERROR;
        }

        DEBUG_LOG(source, "validating parameter");
        if ((int) param->dataType != TokenType_Keyword_toSymbolType(param_type_token->type))
        {
            //  Datový typ aktuálního parametru se neshoduje s datovým typem
            //  uvedeným při deklaraci funkce
            DEBUG_ERR(source, "parameter datatypes do not match");

            if (Parser_setError_alreadyDefined(param_name_token, input) != NO_ERROR)
            {
                return INTERNAL_ERROR;
            }

            return SEMANTICAL_DEFINITION_ERROR;
        }

        //  Vytvoření symbolu pro daný parametr
        //  vytváří se na lokálním rámci, protože pushframe, který "instrukčně" příjde později
        //  jsme pro tabulku symbolů již udělali
        result = SymbolTable_insert(symtable, param_name_token->attr, TokenType_Keyword_toSymbolType(param_type_token->type), LOCAL_FRAME, param_name_token->attr, &symbol);
        if (result != NO_ERROR)
        {
            return result;
        }

        SymbolStack_push(symbol_stack1, symbol);
        SymbolInfo_Function_ParameterList_next(paramList);
    }
    while(true);

    if (SymbolInfo_Function_ParameterList_get(paramList) != NULL)
    {
        DEBUG_ERR(source, "there are more parameters defined in function declaration");
        return SEMANTICAL_DATATYPE_ERROR;
    }

    DEBUG_LOG(source, "parsing function return type");

    //  <AS>
    result = Parser_getToken(source, input, nlevel, AS, NULL);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  <INTEGER|STRING|DOUBLE|BOOLEAN>
    result = Parser_getToken(source, input, nlevel, NO_REQUIRED_TYPE, &func_type_token);
    if (result != NO_ERROR)
    {
        return result;
    }

    if (Token_isDataType(func_type_token) == false)
    {
        if (Parser_setError_statement("INTEGER, STRING, DOUBLE or BOOLEAN", func_type_token, input))
        {
            return INTERNAL_ERROR;
        }
        return SYNTAX_ERROR;
    }

    DEBUG_LOG(source, "validating function datatype");
    if ((int) func_info->dataType != TokenType_Keyword_toSymbolType(func_type_token->type))
    {
        DEBUG_ERR(source, "function return datatype does not match");
        return SEMANTICAL_DATATYPE_ERROR;
    }

    //  <LINE_END>
    result = Parser_getToken(source, input, nlevel, LINE_END, NULL);
    if (result != NO_ERROR)
    {
        return result;
    }

func_def_newlyDeclared:
    DEBUG_LOG(source, "creating nesting level");
    nlevel = NestingList_newLevel(nlist, NESTING_FUNCTION, func_symbol);
    NestingList_debugPrint(nlist);

    DEBUG_LOG(source, "creating initial instructions");
    Instruction_custom(ilist, "\n# FUNCTION");
    //  Vytvoření návěstí funkce
    result = Instruction_label(ilist, func_symbol->key);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  Vytvoření nového rámce pro dočasné proměnné funkce
    result = Instruction_createframe(ilist);
    if (result != NO_ERROR)
    {
        return result;
    }

    DEBUG_LOG(source, "resorting parameter symbol stack");
    //  Kontrola jmen parametrů (pokud se odlišuje definice od deklarace)
    while (SymbolStack_isEmpty(symbol_stack1) == false)
    {
        //  Přerovnání stacku, symboly nyní půjdou od prvního po poslední
        SymbolStack_push(symbol_stack2, SymbolStack_top(symbol_stack1));
        SymbolStack_pop(symbol_stack1);
    }

    DEBUG_LOG(source, "validating parameter names");
    SymbolInfo_Function_ParameterList_first(paramList);
    while (SymbolStack_isEmpty(symbol_stack2) == false)
    {
        param = SymbolInfo_Function_ParameterList_get(paramList);
        symbol = SymbolStack_top(symbol_stack2);

        if (strcmp(symbol->key, param->name) != 0)
        {
            //  Pokud se jméno parametru v definici funkce neshoduje s názvem
            //  v deklaraci funkce, je nutné proměnnou vytvořit zde a přesunout
            //  hodnoty ze starého parametru do nového
            SymbolPtr oldParam = Symbol_create(param->name, param->dataType, LOCAL_FRAME, param->name);

            result = Instruction_variable_assign(ilist, symbol, oldParam);
            if (result != NO_ERROR)
            {
                return result;
            }
        }

        SymbolStack_pop(symbol_stack2);
        SymbolInfo_Function_ParameterList_next(paramList);
    }

    //-------------------------------------------------d-d-
    //  Parsování vnitřního kódu funkce
    //-----------------------------------------------------
    DEBUG_LOG(source, "calling Parser_ParseNestedCode");
    result = Parser_ParseNestedCode(input, ilist, symtable, nlist);
    if (result != NO_ERROR)
    {
        return result;
    }
    DEBUG_LOG(source, "return from Parser_ParseNestedCode");

    //-------------------------------------------------d-d-
    //  Závěrečné tokeny
    //-----------------------------------------------------
    DEBUG_LOG(source, "creating ending instructions");
    //  <END>
    result = Parser_getToken(source, input, nlevel, END, NULL);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  <FUNCTION>
    result = Parser_getToken(source, input, nlevel, FUNCTION, NULL);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  <LINE_END>
    result = Parser_getToken(source, input, nlevel, LINE_END, NULL);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  Nastavení implicitní návratové hodnoty v případě,
    //  že uživatel nepoužil return ale dožaduje se hodnoty
    {
        if (func_info->dataType == ST_INTEGER)
        {
            result = Instruction_custom(ilist, "PUSHS int@0");
        }
        else if (func_info->dataType == ST_DOUBLE)
        {
            result = Instruction_custom(ilist, "PUSHS float@0.0");
        }
        else if (func_info->dataType == ST_STRING)
        {
            result = Instruction_custom(ilist, "PUSHS string@");
        }
        else if (func_info->dataType == ST_BOOLEAN)
        {
            result = Instruction_custom(ilist, "PUSHS bool@false");
        }
        else
        {
            result = INTERNAL_ERROR;
        }
        if (result != NO_ERROR)
        {
            return result;
        }
    }

    //  Zrušení rámce pro dočasné proměnné funkce
    //  (smaže dočasné proměnné funkce)
    result = Instruction_popframe(ilist);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  Instrukce pro návrat
    result = Instruction_return(ilist);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  Provedeme změny i v tabulce symbolů
    //  nejdříve odstraní lokální proměnné funkce vytvořené
    //  v Parser_ParseNested
    SymbolTable_popFrame(symtable);
    //  Provedeme změny i v tabulce symbolů
    //  následně odstraní parametry funkce
    SymbolTable_popFrame(symtable);

    Instruction_custom(ilist, "# END FUNCTION");

    DEBUG_LOG(source, "removing current nesting level");
    NestingList_leaveCurrentLevel(nlist);
    NestingList_debugPrint(nlist);

    return NO_ERROR;
}

int Parser_ParseFunctionCall(InputPtr input, InstructionListPtr ilist, SymbolTablePtr symtable, SymbolPtr func_symbol)
{
    //               |->
    //  <IDENTIFIER> | <OPEN_BRACKET> {[<COMMA] <IDENTIFIER|CONSTANT>}* <CLOSE_BRACKET>
    //

    //-------------------------------------------------d-d-
    //  Inicializace
    //-----------------------------------------------------
    char *source = "parser-func_call";
    int result;

    TokenPtr  token;
    SymbolPtr symbol;

    PostfixListPtr postfix;

    SymbolInfo_FunctionPtr func_info = (SymbolInfo_FunctionPtr) func_symbol->value;
    SymbolInfo_Function_ParameterListPtr paramList = func_info->params;
    SymbolInfo_Function_ParameterPtr func_param = NULL;

    //-------------------------------------------------d-d-
    //  Zpracování tokenů
    //-----------------------------------------------------
    //  <OPEN_BRACKET>
    result = Parser_getToken(source, input, NULL, OPEN_BRACKET, NULL);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  Posunutí aktuálního rámce výše
    result = Instruction_pushframe(ilist);
    if (result != NO_ERROR)
    {
        return result;
    }
    SymbolTable_pushFrame(symtable);

    //  Vytvoření nového rámce pro parametry funkce
    result = Instruction_createframe(ilist);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  PARAMETERS
    DEBUG_LOG(source, "parsing parameters");
    SymbolInfo_Function_ParameterList_first(paramList);
    do
    {
        //  Načtení dalšího parametru z deklarace funkce
        func_param = SymbolInfo_Function_ParameterList_get(paramList);
        DEBUG_LOG(source, "validating parameter, expected is");
        SymbolInfo_Function_Parameter_debugPrint(func_param);
        if (func_param == NULL)
        {
            //  Funkce nemá žádné parametry
            DEBUG_LOG(source, "this function receives no parameters, exiting loop");
            break;
        }

        //  Vyhodnocení výrazu
        DEBUG_LOG(source, "calling Parser_ParseExpression");
        result = Parser_ParseExpression(input, ilist, symtable, &postfix, true);
        if (result != NO_ERROR)
        {
            DEBUG_ERR(source, "failed to parse expression");
            return result;
        }
        DEBUG_LOG(source, "return from Parser_ParseExpression");

        PostfixList_debugPrint(postfix);

        DEBUG_LOG(source, "calling postfix2instructions");
        SymbolType result_dt;
        result = postfix2instructions(input, ilist, symtable, &postfix, func_param->dataType, &result_dt);
        if (result != NO_ERROR)
        {
            DEBUG_ERR(source, "failed convert postfix to instructions");
            return result;
        }
        DEBUG_LOG(source, "return from postfix2instructions");

        //  Výsledek výrazu se aktuálně nachází na stacku,
        //  stačí ho jen přiřadit novému parametru
        DEBUG_LOG(source, "creating temporary symbol");

        //  Vytvoření dočasného symbolu pro práci s instrukcemi proměnných
        char *func_param_val = String_create(func_param->name);
        if (func_param_val == NULL)
        {
            return INTERNAL_ERROR;
        }
        symbol = Symbol_create(func_param->name, func_param->dataType, TEMPORARY_FRAME, func_param_val);
        if (symbol == NULL)
        {
            DEBUG_ERR(source, "failed to create temp symbol");
            return INTERNAL_ERROR;
        }
        Symbol_debugPrint(symbol);

        DEBUG_LOG(source, "creating param instructions");
        //  Vytvoření parametru
        result = Instruction_defvar(ilist, symbol);
        if (result != NO_ERROR)
        {
            return result;
        }

        //  Přiřazení hodnoty parametru
        result = Instruction_stack_pop(ilist, symbol);
        if (result != NO_ERROR)
        {
            return result;
        }

        DEBUG_LOG(source, "this parameter is completed, fetching next token");
        //  Načtení dalšího tokenu
        result = Parser_getToken(source, input, NULL, NO_REQUIRED_TYPE, &token);
        if (result != NO_ERROR)
        {
            return result;
        }

        if (token->type == COMMA)
        {
            DEBUG_LOG(source, "received comma, expecting more parameters, continuing");
            //  Měl by následovat další parametr
            Token_destroy(&token);

            //  Posunutí na další parametr v deklaraci funkce
            SymbolInfo_Function_ParameterList_next(paramList);
        }
        else
        {
            DEBUG_LOG(source, "received something not part of this expression, maybe close bracket");
            Scanner_UngetToken(input, &token);
            break;
        }
    }
    while(true);
    DEBUG_LOG(source, "parameter parsing completed");

    //  <CLOSE_BRACKET>
    result = Parser_getToken(source, input, NULL, CLOSE_BRACKET, NULL);
    if (result != NO_ERROR)
    {
        return result;
    }

    DEBUG_LOG(source, "creating instructions");

    //  Samotný skok na návěstí funkce a další pushframe
    //  který jsme ovšem v rámci práce s lokální tabulkou symbolů
    //  provedli už dříve
    result = Instruction_pushframe(ilist);
    if (result != NO_ERROR)
    {
        return result;
    }
    result = Instruction_call(ilist, func_symbol);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  Toto je první instrukce po návratu z funkce
    //  smaže rámec s parametry funkce
    result = Instruction_popframe(ilist);
    if (result != NO_ERROR)
    {
        return result;
    }
    SymbolTable_popFrame(symtable);

    DEBUG_LOG(source, "function call successfully parsed");
    return NO_ERROR;
}


//-------------------------------------------------d-d-
//  Proměnné
//-----------------------------------------------------

int Parser_ParseVariableDeclaration(InputPtr input, InstructionListPtr ilist, SymbolTablePtr symtable, NestingListPtr nlist)
{
    //        |->
    //  <DIM> | <IDENTIFIER> <AS> <INTEGER|STRING|DOUBLE|BOOLEAN> <LINE_END>
    //

    //-------------------------------------------------d-d-
    //  Inicializace
    //-----------------------------------------------------
    char *source = "parser-var_dec";
    int result;

    TokenPtr token;
    NestingLevelPtr nlevel = NestingList_active(nlist);

    char        *var_name;
    SymbolType  var_type;
    SymbolPtr   var;

    //-------------------------------------------------d-d-
    //  Zpracování tokenů
    //-----------------------------------------------------
    //  <IDENTIFIER>
    result = Parser_getToken(source, input, nlevel, IDENTIFIER, &token);
    if (result != NO_ERROR)
    {
        Token_destroy(&token);
        return result;
    }

    var_name = token->attr;
    Token_destroy(&token);

    //  <AS>
    result = Parser_getToken(source, input, nlevel, AS, NULL);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  <INTEGER|STRING|DOUBLE|BOOLEAN>
    result = Parser_getToken(source, input, nlevel, NO_REQUIRED_TYPE, &token);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  Datový typ je v pořádku, zvolíme adekvátní typ symbolu
    switch (token->type)
    {
        case INTEGER:
            var_type = ST_INTEGER;
            break;
        case STRING:
            var_type = ST_STRING;
            break;
        case DOUBLE:
            var_type = ST_DOUBLE;
            break;
        case BOOLEAN:
            var_type = ST_BOOLEAN;
            break;
        default:
            //  Byl očekáván datový typ, který jsme ale nedostali
            DEBUG_ERR(source, "this type of token was not expected!");
            Token_debugPrint(token);

            if (Parser_setError_statement("INTEGER, STRING, DOUBLE or BOOLEAN", token, input) != NO_ERROR)
                return INTERNAL_ERROR;

            Token_destroy(&token);
            return SYNTAX_ERROR;
            break;
    }
    Token_destroy(&token);

    //  Vytvoření symbolu proměnné
    result = SymbolTable_insert(symtable, var_name, var_type, TEMPORARY_FRAME, var_name, &var);
    if (result != NO_ERROR)
    {
        //  Při vytváření symbolu došlo k chybě
        DEBUG_ERR(source, "failed to create symbol");
        return result;
    }
    else
    {
        //  Symbol byl úspěšně vytvořen
        DEBUG_LOG(source, "symbol successfully created");
        Token_debugPrint(token);
        SymbolTable_debugPrint(symtable);

        result = Instruction_variable_declare(ilist, var);
        if (result != NO_ERROR)
        {
            return result;
        }
    }

    //  <EQ|LINE_END>
    result = Parser_getToken(source, input, nlevel, NO_REQUIRED_TYPE, &token);
    if (result != NO_ERROR)
    {
        return result;
    }

    if (token->type == EQ)
    {
        //  Proměnná bude rovnou i definována
        DEBUG_LOG(source, "calling ");
        result = Parser_ParseVariableDefinition(input, ilist, symtable, nlist, var);
        if (result != NO_ERROR)
        {
            return result;
        }
    }
    else if (token->type != LINE_END)
    {
        //  Proměnná není ani rovnítko, ani konec řádky, jedná se o syntax err
        //  TODO: error message
        return SYNTAX_ERROR;
    }

    return NO_ERROR;
}

int Parser_ParseVariableDefinition(InputPtr input, InstructionListPtr ilist, SymbolTablePtr symtable, NestingListPtr nlist, SymbolPtr variable)
{
    //                    |->
    //  <IDENTIFIER> <EQ> | _EXPRESSION_ <LINE_END>
    //

    //-------------------------------------------------d-d-
    //  Inicializace
    //-----------------------------------------------------
    char *source = "parser-var_def";
    int result;

    PostfixListPtr postfix = NULL;

    NestingLevelPtr nlevel = NestingList_active(nlist);


    //-------------------------------------------------d-d-
    //  Zpracování tokenů
    //-----------------------------------------------------

    //  _EXPRESSION_
    DEBUG_LOG(source, "calling Parser_ParseExpression");
    result = Parser_ParseExpression(input, ilist, symtable, &postfix, false);
    if (result != NO_ERROR)
    {
        DEBUG_ERR(source, "expression failed to be parsed");
        PostfixList_destroy(&postfix);
        return result;
    }

    DEBUG_LOG(source, "postfix conversion completed, calling postfix2instructions");
    SymbolType result_dt;
    result = postfix2instructions(input, ilist, symtable, &postfix, variable->type, &result_dt);
    if (result != NO_ERROR)
    {
        return result;
    }

    DEBUG_LOG(source, "instruction conversion completed, cleaning up");
    PostfixList_destroy(&postfix);

    //  Načtení výsledku do proměnné
    result = Instruction_stack_pop(ilist, variable);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  Vyčištění stacku
    result = Instruction_stack_clear(ilist);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  <LINE_END>
    result = Parser_getToken(source, input, nlevel, LINE_END, NULL);
    if (result != NO_ERROR)
    {
        return result;
    }

    return NO_ERROR;
}


//-------------------------------------------------d-d-
//  IFy
//-----------------------------------------------------

int Parser_ParseCondition(InputPtr input, InstructionListPtr ilist, SymbolTablePtr symtable, NestingListPtr nlist)
{
    //       |->
    //  <IF> | _EXPRESSION_ <THEN> <LINE_END>
    //  {_CODE_ <LINE_END>}*
    //  <ELSE> <LINE_END>
    //  OR
    //  <ELSEIF> _CONDITION_
    //  {_CODE_ <LINE_END>}*
    //  <END> <IF> <LINE_END>
    //

    //-------------------------------------------------d-d-
    //  Inicializace
    //-----------------------------------------------------
    char *source = "parser-cond";
    int result;

    TokenPtr  token;
    SymbolPtr cond_symbol;

    PostfixListPtr postfix;

    NestingLevelPtr nlevel = NestingList_active(nlist);


    //-------------------------------------------------d-d-
    //  Zpracování tokenů
    //-----------------------------------------------------
    Instruction_custom(ilist, "# IF BLOCK");

    //  _EXPRESSION_
    DEBUG_LOG(source, "calling Parser_ParseExpression");
    result = Parser_ParseExpression(input, ilist, symtable, &postfix, false);
    if (result != NO_ERROR)
    {
        DEBUG_ERR(source, "failed to parse expression");
        return result;
    }

    Instruction_custom(ilist, "# IF");

    //  Zpracování podmínky
    DEBUG_LOG(source, "calling postfix2instructions");
    SymbolType result_dt;
    result = postfix2instructions(input, ilist, symtable, &postfix, ST_BOOLEAN, &result_dt);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  <THEN>
    result = Parser_getToken(source, input, NULL, THEN, NULL);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  <LINE_END>
    result = Parser_getToken(source, input, NULL, LINE_END, NULL);
    if (result != NO_ERROR)
    {
        return result;
    }

    DEBUG_LOG(source, "creating condition identifiers and symbols");
    char cond_symbol_id[5];
    sn_r-co

    at}


//UG_LOG(source, "creatingt_dt;tasLOG(sourcn}

    //unt++� podmínky
Iunget
      G(source, "callcond";rce, "creati Token_m->name)oncat(DE_ _      TokN   ifrce, "creatingt_"_info->dataTyrce, "creati TokenEBUG_ERR(source, "ther        }
        return SY}odmínky
Iunget
      Ge o -----holší pushf"callcond";rce, ee, l->keen_m->name)oncat(rce, "creati Tokt_"ult"t_"_info->dacond";rce, blo (ree, l->keen_m->name)oncat(rce, "creati Tokt_"ESSIO_ult"t_"_infoodmínky
vytvoř(source, "callcce, "creataram->name, func_rce, "creati Tokt_;
 DE_ &func_symbolrce, blo (ree, l->kenfo->dataTyrce, "createnEBUG_ERR(source, "thered to parse expressnd symbols"create        PostfionocebugPrint(token)nt("INTEGER, STRionocebble,t;
    }

    Inst }
        return SY}, "creating instructions");

    /newlevel = NestingList_newLevel(nlist, NESTING_FUNCTION, func_symbol);DE_ <LINEifrce, "creatO_ERROR)
  wLevel(n return INTERNAL_ERROR;
    }

    SymbolInfo_Functi == EQ)nlist);

    return NO_ERROR;
}

int Pom(ilist, "PUSHS bool@false");
        }
  urce"_ERROR)
    {
        return result;
    }

    //  Vyčištění stacku
    řesné pr(source, "call Pom(ilist, "PUSHS bojumpifneq  if (se");
 rce, ee, l->ke_ERROR)
    {
        return result;
    }

    //  Vyčištění stackt, "# IF");

    //  Zpracov�sultN_
    DEBUG_L//  <"calling Parser_ParseExpression");
    result = Parser_ParseNestedCode(input, ilist, symtable, nlist);
    if (result != NO_ERROR)
    {
        return result;
    }
    DEBUG_LOG(source, "return from Parser_ParseNestedCode");

    //-----------------------x;

        DEém opuult = Insvner_Pars---------ce a dale o syblosul(sourceek"call Pom(ilist, "PUSHS bojumpse");
 rce, blo (ree, l->kenfo->dataTy {
        return result;
    }

    //  Vyčištění stacku
    �nné
    e o -----holší pushfr(source, "call Pom(ilist, "PUSHS bol->key);
    rce, ee, l->ke_ERROR)
    {
        return result;
    }

    //  Vyčištění ěn�m->name //  Načrce, ee, l->ke_ERITION_
    // | //  {|r_getToken(source, input, NULL, LINE_END, NULL);
    ifn);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  Datový typ jeTION_
  Blosl(sourceekl(skračujeRROR)
    {
        //  //  {i vytváření symboNmetr
 ce)
/  kter�source,rce, "calling ");
        result = P);

    //--Subt, Instrurser_ParseExpression(input, ilistSubt, Instru, nlist);
    if (result != NO_ERROR)ROR)
    {
        return resultvytváření sssss            return SYNTAX_ERROR;
         

    //  <EQ|LINE_ENDreturn from Parser_ParseNestedCode");

    //--Subt, Instrurseor <CLOSE_BRACKE // | _getTokeToken(source, input, NULL, LINE_END, NULL);
    ifn);
    if (result != NO_ERROR)ROR)
    {
        return resultvytváření sssss}
    }

    //  <EQ|LINE_END>= EQ)
    {
        //  // i vytváření symboNmetr
 ce)e o ----�yblos Symbol byyyyyt, "# END FUNCTION");

    D// rser_setErrorBUG_L//  <"callcalling ");
        result = P);

    //---------------------ssss            return SYNTAX_ERRORstedCode(input, ilist, symtable, nlist);
    if (result != NO_ERROR)ROR)
    {
        return resultvytváření sssss}
    }

    //  <EQ|LINurce, "creating param instructeNestedCode");

    //----------------Q|LINE_END LINE_END)
    {
       Pr vytváření symboT ani zavír    mbolté
buejít !aushý j  TODO: error�ření symboT        Token_destroy(&toke        return result;
    }

    var_  DEBUG_LOG(source, _END LIN vytváření symboT ani e){
usult !   Dme
  �mu e užlara brz(source, "t, &token);
            break;
 tění stacku
  Nmetr
 ce)úpl--�ye o syblosuITION_
    _getToken(source, input, NULL, LINE_END, NULL);
    ifult != NO_ERROR)
    {
        return result;
    }

    //  <FUNCTION>
    result = IFetToken(source, input, NULL, LINE_END, NULL);
    ifIF != NO_ERROR)
    {
        return result;
    }

    //  <LINE_END>
    result = Parser_getToken(source, input, NULL, LINE_END, NULL);
    if (result != NO_ERROR)
    {
        return result;
    }

    DEBUG_LOG(source, urcet, "# END FUNCTION");

    DEBU�ní podmínky
  �nné
    e o -----holší pushfrblosul(sourceek"call Pom(ilist, "PUSHS bol->key);
    rce, blo (ree, l->kenfo->dataTy {
        return result;
    }

 m->name //  Načrce, blo (ree, l->kenfo->da}

    DEBUG_LOG(source, urcem->name //  Načrce, blo (ree, l->kenfoodmínky
Opuult = Instoh po zaner_Par�"return from Parser_Parsoop");
 ;
    NestingList_leave EQ)nlist);

   );
    NestingList_debugPrint(nlist);

    return NO_ERROR;
}

intt, "# END FUNCTION");

    DEBU�nRESSION_
    DEol successfully crea        Tokepart of tult !terminiers and symbol;
}


//--------------------on(InputPtr inpuSubt, Instru,tionListPtr ilist, SymbolTablePtr symtable, NestingListPtr nlist)
{
    //       |->
    //odmínk--------------------------d-d-
    //  Zpracování tokenů
  -------------------------------------------------
    char *source = "parser-cond";
    int result;

   _sub TokenPtr token;
    NestingLevelPtr nle  Nes

    NestingLevelPtr nlevel = NestingList_active(nlist);


    //-------------------------------------------------d-d-
    //  Zpracování tokenů
    //-----------------------------------------------------
    Instruction_custom(ilist, "# IF BLOCK");

   

    D// �ní podmínky
LOG(source, "calling Parser_ParseExpression");
    result = Parser_ParseExpression(input, ilist, symtable, &postfix, false);
    if (result != NO_ERROR)
    {
        DEBUG_ERR(source, "failed to parse expression");
        return result;
    }

    Instruct(source, "loading symbol informateExpression");

        PostfixListpodmínky
    DEBUG_LOG(source, "call   result = postfix2instructions(input, ilist, symtable, &postfix, ST_BOOLEAN, &result_dt);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  <THEN>
    result = Parser_getToken(source, input, NULL, THEN, NULL);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  <THEN>
    result = ParsParser_getToken(source, input, NULL, LINE_END, NULL);
    if (result != NO_ERROR)
    {
        return result;
    }

    DEBUG_LOG(source, "calling Parser_ParseExpr

    /sub-nd symbols");
    chal_id[5];
    sn_r-co

    at}


//UG_LOG(source, "creatingt_dt;tasLOG(sourcn}

    //unt++� podmínky
Iunget
      G(source, "callcond";rce, "creati Token_m->name)oncat(DE_ _      TokN   ifrce, "creatingt_"_info->dataTyrce, "creati TokenEBUG_ERR(source, "t

    DEBU }
        return SY}odmínky
Iunget
      Ge o -----holší pushf"callcond";rce, ee, l->keen_m->name)oncat(rce, "creati Tokt_"ult"t_"_info->dacond";rce, blo (ree, l->keen_tive(n->olInfo_Function"call Pom(ilist, "PUSHS bool@false");
        }
  urce"_ERROR)
    {
        return result;
    }

    //  Vyčištění stacku
    řesné pr(source, "call Pom(ilist, "PUSHS bojumpifneq  if (se");
 rce, ee, l->ke_ERROR)
    {
        return result;
    }

    //  Vyčištění st ckt, "# IF");

    //  Zpracov�sultN_
    DEBUG_L//  <"calling Parser_ParseExpression");
    result = Parser_ParseNestedCode(input, ilist, symtable, nlist);
    if (result != NO_ERROR)
    {
        return result;
    }
    DEBUG_LOG(source,"loading symbol informateExpression");

      ---------------------x;

        DEém opuult = Insvner_Pars---------ce a dale o syblosul(sourceek"call Pom(ilist, "PUSHS bojumpse");
 rce, blo (ree, l->kenfo->dataTy {
        return result;
    }

    //  Vyčištění stacku
    �nné
    e o -----holší pushfr(source, "call Pom(ilist, "PUSHS bol->key);
    rce, ee, l->ke_ERROR)
    {
        return result;
    }

    //  Vyčištění ITION_
    // | //  {|r_getToken(source, input, NULL, LINE_END, NULL);
    ifn);
    if (result != NO_ERROR)
    {
        return result;
    }

    //  Datový typ jeTION_
  Blosl(sourceekl(skračujeRROR)
    {
        //  //  {i vytváření symboNmetr
 ce)
/  kter�source,rce, "calling ");
        result = P);

    //--Subt, Instrurser_ParseExpression(input, ilistSubt, Instru, nlist);
    if (result != NO_ERROR)ROR)
    {
        return resultvytváření sssss            return SYNTAX_ERROR;
         

    //  <EQ|LINE_ENDreturn from Parser_ParseNestedCode");

    //--Subt, Instrurseor <CLOSE_BRACKE // | //  {|r_getTokeToken(source, input, NULL, LINE_END, NULL);
    ifn);
    if (result != NO_ERROR)ROR)
    {
        return resultvytváření sssss}
    }

    //  <EQ|LINE_END>= EQ)
    {
        //  // i vytváření symboNmetr
 ce)e o ----�yblos Symb, v    im     z   t dal�ejvyš kterú resňE_ENDreturn from Parser_ParseNrt of tu// ,s}
    

         Nc, Instrurseor_ENDretut, &token);
            break;
        }
 -----------------Q|LINE_END LINE_END)
    {
       Pr vytváření symboT ani zavír    mbolté
buejít !aushý j  TODO: error�ření symboT        Token_destroy(&toke        return result;
    }

    var_  DEBUG_LOG(source, _END LIN vytváření symboNmetr
 ce)úpl--�ye o syblosuITIONreturn from Parser_ParseNrt of tult !}
    

         Nc, Instrurser_ENDretut, &token);
            break;
       }
 -----------------Q|LINE
}

    var_  DEBUG_LOG(so--------------------------------d-d-
//  IFy
//-----------------Cykl----------------------------------

int Parser_ParseCondition(InputPtr inpuLoop_DoctionListPtr ilist, SymbolTablePtr symtable, NestingListPtr nlist)
{
    //       |->
    //  <IF> | _EXPRESSION_ <THEDOINTEGWHILE>>
    //

    //---------------    //  <END> <IF> <LINE_END>
  LOOP  //-------------------------------------------------d-d-
    //  Inicializace
    //-----------------------------------------------------
    char *source = "parser-cond";
    int result;
eak;_do TokenPtr token;
    Nes
    Postfeak;_tPtr postfix;

    NestingLevelPtr nlevel = NestingList_active(n------------------------------------d-d-
    //  Zpracování tokenů
    //-----------------------------------------------------
    Instruction_custom(ilisD>
  WHILE>tToken(source, input, NULL, LINE_END, NULL);
 );


    //-------------, WHILE != NO_ERROR)
    {
        return result;
    }

    //  <THEN>
    result = ParLOG(source, "calling Parser_ParseExpression");
    result = Parser_ParseExpression(input, ilist, symtable, &postfix, false);
    if (result != NO_ERROR)
    {
        DEBUG_ERR(source, "failed to parse expression");
        return result;
    }

    InstructG(source, "calling Parser_ParseExpr

    /eak;s");
    char cond_symbol_id[5];
    eak;_tPtr p   at}


//UG_LOG(soueak;_tPtr p   t_dt;tasLOG(sourcn}

eak;//unt++� podmícond";eak;_tPtr p  Token_m->name)oncat(LOOP_      TokN   ifeak;_tPtr p   t_"_info->dataTyeak;_tPtr p  TokenEBUG_ERR(source, "t

    DEBU }
        return SY}odmícond";eak;_begin l->keen_m->name)oncat(eak;_tPtr p  Tokt_"EEGIN"t_"_info->dacond";eak;_ee, l->kee en_m->name)oncat(eak;_tPtr p  Tokt_"ult"t_"_infoodmínky
  �nné
    lInfrm   i    yklu  Nes
    PList_Loopostfeak;_tionPtr
    PList_Loope, func_eak;_begin l->keifeak;_ee, l->ke_ERROR)
   eak;_tionPtEBUG_ERR(source, "t

 nt("INTEGER, STRionocebble,t;
    }

    Inst }
        return SY}rseExpression(able, var_name, var_type, TEMeak;_tPtr p  Tokt_ST_LOOP&func_symboleak;_tion ifeak;_tPtr p_ERROR)
    {
        DEBUG_ERR(source, "failnt("INTEGER, STRionocebble,t;
    }

    InstructG(source, "calling Parser_ParseExpr

    /newlevel = NestingList_newLevel(nlist, NESTING_FUNCTION, func_symbol);LOOP&feak;_tPtr p_EPrint(nlist);

    return NO_ERROR;
}

intymboT     Hrátky s CREATE
     atd.oodmínky
  �nné
    počát ----�holší pushfr yklu  Nes Pom(ilist, "PUSHS bol->key);
    eak;_tion->begin l->ke_ERROR)
    {
        return result;
    }

    //  <THEN>
    result = Par    DEBUG_LOG(source, r yklPar�"return from Parser_Parstions");
    SymbolType result_dt;
    result = postfix2instructions(input, ilist, symtable, &postfix, ST_BOOLEAN, &result_dt);
    if (result != NO_ERROR)
    {
        return result;
    }

 ed to parse expression");
    ro    return result;
    }

    InstructG(source, "call--x;

ource = Inkce a dalzáklvate�
    resul(source, "call do prstructametrdám TRUE  Nes Pom(ilist, "PUSHS bool@false");
        }
  urce"_ERROR)
    {
        return result;
    }

    //  Vyčištění call do pametry funTRUE  stačí l(sly nynvám s�
    reseml(source, "call do nice o�ejsovedtejnét !aushýale o sy yklu  Nes Pom(ilist, "PUSHS bojumpifneq  if (se");
 eak;_tion->ee, l->ke_ERROR)
    {
        return result;
    }

    //  Vyčištění ITION_
   Parser_getToken(source, input, nlevel, LINE_END, NULL);
    if (result != NO_ERROR)
    {
        return result;
    }

    return NO_ERROR;
}


//BUG_L//  <"calling Parser_ParseExpression");
    result = Parser_ParseNestedCode(input, ilist, symtable, nlist);
    if (result != NO_ERROR)
    {
        return result;
    }
 ed to parse expression");
        rn symtNc,er_ParseNe}

    //  Vyčištění ITION_
   POOP tToken(source, input, nlevel, LINE_END, NULL);
    if OOP&f= NO_ERROR)
    {
        return result;
    }

    //  <THEN>
    result = ParsParser_getToken(source, input, NULL, LINE_END, NULL);
;
    if (result != NO_ERROR)
    {
        return result;
    }

    return NO_ERROR;
}


//BUG_Se a z   t dalzačát k a znovu(sly nyn� pr(source, "call Pom(ilist, "PUSHS bojumpy);
    eak;_tion->begin l->ke_ERROR)
    {
        return result;
    }

    //  <THEN>
    result = Par  �nné
    e o -----holší pushfr yklu  Nes Pom(ilist, "PUSHS bol->key);
    eak;_tion->ee, l->ke_ERROR)
    {
        return result;
    }

    //  Vyčištění ITIONrn from Parser_Parsoop");
 ;
    NestingList_leave EQ)nlist);

   );
    NestingList_debugPrint(nlist);

    return NO_ERROR;
}

int-------------------
/*ion(InputPtr inpuLoop_ForctionListPtr ilist, SymbolTablePtr symtable, NestingListPtr nlist)
{
    //        |->
    //  <DIM> | <IDENTIFIER> <ASFOCOMMA??? //---------------    //  <END> <IF> <LINE_END>
  LOOP  //-------------------------------------------------d-d-
    //  Inicializace
    //-----------------------------------------------------
    char *source = "parser-cond";
    int result;
eak;_nfr TokenPtr ts, &tokeVyčištěn�tr tesult;eVyčišttěn�tingLevelPtr nle 

int------- }
        retur}
*/-------------------------------d-d-
//  IFy
//-----------------SNG, DOUB----------------------------------

int Parser_ParseCondition(InputPtr inpuSNG, DOUB_rn NO_tionListPtr ilist, SymbolTablePtr symtable, NestingListPtr nlist)
{
    //        |->
    //  <DIM> | <IDIDENTIFIER> <ASPR }
OMMA{
    //

    /SEMICOLON //

/-------------------------------------------------d-d-
    //  Inicializace
    //-----------------------------------------------------
    char *source = "parser-cond";
    int result;
LOG(s"_ERROR)r  token;
    SymbolPtr cond_sy velPtr nl  Sy
    Postf    vnd"elPtr n == EQ)

    NestingLevelPtr name(symtable)lt = postfix2inrint(nlist);
gList_active(nlist);


    //-------------------------------------------------d-d-
    //  Zpracování tokenů
    //-----------------------------------------------------
    Instruction_customor <CLOačtení dalšíhoing Parser_ParseExpression");
    result = Parser_Paer_ParseVariableDefinition(inpu, symtable, &postfix, false);
    if (result != NO_E NO_ERROR)
        {
            return result;
        }
    }
    else if (token->íhoing Parser_ParseExpeExpression");

        PostfixList_debugPrint(ing Parser_ParseExpructions");
    Sy         return reser_ParseVariableDefput, ilist, symtable, &postfix, ST_BOOLEAN, &result_dt)n);
    if (result ult != NO_E NO_ERROR)
        {
            return result;
        }

        //  Přiřazení hodnoting Parser_ParseExp NU;

        //lt != NO return INTERNAL_ERR    vnd"elable, var_na NUL   Varr_type, TEMix, ST_ult != NO, 0_E NO_ERROR)
      vnd"e         DEBUG_ERR(source, "failed to create temp symbol");
 NU
        //lt != NO return INTERNAL_ERR     }

   }
        Symbol_debugPrint(symbol);

        DEBU    vndst_debugPrint(ing Parser_ParseExpsp");
  parsed");
      {;
     vndreser_ParseVariableDeflist, variable);
    if (resu    vndst_dO_ERROR)
        {
            return result;
        }

        //  Přiřazení hodnotriableDeflist, variabwriteif (resu    vndst_dO_ERROR)
        {
            return result;
        }

        //  Přiřar <CLOSE_BRACKESEMICOLON r_ParseVariableDefinition NULL, LINE_END, NULL);
;
    ifSEMICOLON != NO_ERROR)ROR)
        {
           return reult;
        }

        /  Přiřar <CLOSE_BRACKE/-------- ?r_ParseVariableDefinition NULL, LINE_END, NULL);
;
    ifn);
        if (result != NO_ERROR)
        {
            return result;
        }

        if (token->type == COMMA)
        {
         //  Pr return result;
       RACKUe oč
    posloupnsuli(source, "failed to m Parser_ParseNrt of t   //  P!}
    

         Nlly parsr_UngetToken(inputymtable);

     PL   Varr_type, TEM0YNTAX_ERROR;
              return SYNTAX_ERROR;
         ----------Q|LIn->tyngetToken(      result = INTERNAL_ERRORived something not part of this expre, un NU;

 d_sy  con    //  M� partry

        return result;ngetToken(input, &token);
            break;
        }
    }    // ewhile(true);
    DEBUG_LOG(s ource, "

int------- }
        retur}tion(InputPtr inpuSNG, DOUB_tionL_tionListPtr ilist, SymbolTablePtr symtable, NestingListPtr nlist)
{
    //        |->
    //  <DIM> | <IDIDENTIFIER> <ASINPUTINTEGER|STRING|DOU/-------------------------------------------------d-d-
    //  Inicializace
    //-----------------------------------------------------
    char *source = "parser-cond";
    int result;
tr il TokenPtr  token;
    SymbolPtr cond_symbol;

    Postflt != NO elPtr nlevel = NestingList_active(nlist);


    //-------------------------------------------------d-d-
    //  Zpracování tokenů
    //-----------------------------------------------------

    //  _EXPRESSION_
 FIER> <ASI Parser_getToken(source, input, nlevel, IDENTIFIER, &token);
    if (result != NO_ERROR)
    {
        Token_destroy(&token);
    //  Toto je první instdating parameter, expected is"n result;
    lt != NO elable, var_na NUByevel, I nlist)
{!= NO_ERROR)
   lt != NO eEBUG_ERR(sourebugPrint(ing Pacreate temp s"create    foungPrint(token)tement("INTEGER, STRungt, Ied(OR)
                return INTERNAL_ERR   Inst }
        return SY_ERR   InstSEMAf (C   DEFIN<LINE_  return SY}r� instdating parameter, e;

    //  Samotný_ParseNestedCode(list, variab     if (result != NO_ERROR)
    {
        return result;
    }

 ed to create temp symbol");
sp"e//  Samotný_ParseNen);
    //  Toto je prvn�NE_END>
  Larser_getToken(source, input, NULL, LINE_END, NULL);
;
    if (result != NO_ERROR)
    {
        return result;
    }

    return NO_ERROR;
}


//--------------------on(InputPtr inpuSNG, DOUB_C   // e(/*tionListPtr ili*/st, SymbolTablePtr symtab/*le, NestingListPtr nlist)*/
{
    //        |->
    //  <DI--------------------------d-d-
    //  Zpracování tokenů
  -------------------------------------------------
    char *source = "parser-cond";
    int result;

   // e TokenPtr  token;
    Sy= NestingList_active(nlist);


    //is, symtInN, func_symbol);LOOP)    Nes
    Postfeak;_tPtr pen_tive(n->olInfombol;

    PList_Loopostfeak;_tionPtr(
    PList_Loopost)feak;_tPtr p_Function"---------------------------------d-d-
    //  Zpracování tokenů
    //---------------------------------------------
    Instruction_customorROR)
   t);


    //is, symtInN, func_symbol);LOOP) eEB!= NO_ INTERNAL_ERROR;ed to create temp s    inreak;
        }

    }

    SymbolInfo_Functi == EQ)dating parameter, e;

    //  Samotný_ParseNestedCode(list, variabjumpy);
    eak;_tion->begin l->ke_ERROR)
    {
        return result;
    }

    //  <THEN>
    result =--------------------on(InputPtr inpuSNG, DOUB_Exit(/*tionListPtr ili */t, SymbolTablePtr symtab/*le, NestingListPtr nlist)*/
{
    //        |->
    //  <DI--------------------------d-d-
    //  Zpracování tokenů
  -------------------------------------------------
    char *source = "parser-cond";
    int result;
     TokenPtr  token;
    Sy= NestingList_active(nlist);


    //is, symtInN, func_symbol);LOOP)    Nes
    Postfeak;_tPtr pen_tive(n->olInfombol;

    PList_Loopostfeak;_tionPtr(
    PList_Loopost)feak;_tPtr p_Function"---------------------------------d-d-
    //  Zpracování tokenů
    //---------------------------------------------
    Instruction_customorROR)
   t);


    //is, symtInN, func_symbol);LOOP) eEB!= NO_ INTERNAL_ERROR;ed to create temp s    inreak;
        }

    }

    SymbolInfo_Functi == EQ)dating parameter, e;

    //  Samotný_ParseNestedCode(list, variabjumpy);
    eak;_tion->ee, l->ke_ERROR)
    {
        return result;
    }

    //  Vyčištění ITION--------------------on(InputPtr inpuSNG, DOUB_R-----_tionListPtr ilist, SymbolTablePtr symtable, NestingListPtr nlist)
{
    //        |->
    //  <DIM> | <IDIDDENTIFIER> <ASRETURNEND>
    //

    //-------------------------------------------------d-d-
    //  Inicializace
    //-----------------------------------------------------
    char *source = "parser-var_def";
    int resul------ PostfixListPtr postfix = NULL;

    NestingLe
    Sy= NestingList_active(nlist);


    //is, symtInN, func_symbol);FUNCLINE)    Nes
    Postfesult != NOen_tive(n->olInfombol;

    PList_next(parostfesulttionPtr(
    PList_next(parost)fesult != NO_Function"---------------------------------d-d-
    //  Zpracování tokenů
    //-----------------------------------------------------
    Instruction_customorROR)
   t);


    //is, symtInN, func_symbol);FUNCLINE) eEB!= NO_ INTERNAL_ERROR;ed to create temp s    inrlly parsr_UngetToken(
    }

    SymbolInfo_Functi =okenů
  LOG(source, "calling Parser_ParseExpression");
    result = Parser_ParseExpression(input, ilist, symtable, &postfix, false);
    if (result != NO_ERROR)
    {
        DEBUG_ERR(source, "failed to parse expression");
        return result;
    }

    Instruct(source, "loading symbol informateExpression");

        PostfixListpodmírn from Parser_Parstions");
    SymbolType result_dt;
    result = postfix2instructions(input, ilist, symtable, &postfix, ST_BOOLEAN, &result_dt)esulttionRAME, func_psult != NO_ERROR)
    {
        return result;
    }

    //  <THEN>
    resloading symbol informateExpression"
    SymbolType result_dNE_END>
  Larser_getToken(source, input, NULL, LINE_END, NULL);
;
    if (result != NO_ERROR)
    {
        return result;
    }

    return NO_ERROR;
 == EQ)stedCode(list, variab (result != NO_ERROR)
    {
        return r INTERNAL_ERROR;
    }
       //  P�
 == EQ)stedCode(list, variab
    } != NO_ERROR)
    {
        return r INTERNAL_ERROR;
    }
       //  P�
}


//-------------------------------------------------d-d-
//  IFy
//-----------------D/  kte---------------------------------

int Parser_ParseCondition(InputPtr inpuScope_tionListPtr ilist, SymbolTablePtr symtable, NestingListPtr nlist)
{
    //        |->
    //  <DIM> | <IDIDENTIFIER> <ASSCOPEINTEG/---------------    //  <LINE_END>
    //

SCOPEING/-------|FIL-----------------------------------------------d-d-
    //  Inicializace
    //-----------------------------------------------------
    char *source = "parser-var_def";
    int resulscope TokenPtr token;
    NestingLevelPtr nlame(symtablestPtr nnfomb= EQ)dating parameter, e;

    /newlevel = NestingList_ne= NestingList_active(nlist);


    //_FUNCTION, func_symbol);SCOPEt != NO_ERROR)nlist);

    return NO_ERROR;
}

intym--------------------------d-d-
    //  Inicializace
    //----Úvod---------y-------------------------------------
    char *source = "parser-n(source, input, NULL, LINE_END, NULL);
;
    if (result != NO_ERROR)
    {
        return result;
    }

    return NO_ERROR;
}


//----------------------------d-d-
    //  Zpracování tokenů
   aner_Par�z funkce
-------------------------------------
    char *source = "par= EQ)stedCode(able, var_name, var_type, TEM"main"t);
 FUNCLINE&func_symbol    if&"creatO_ERROR)
   {
        return r INTERNAL_ERROR;
    }
       //  P�
 =/  P�t, "PUSHS bool@false");
  \n# MAINgList_net, "PUSHS bol->key);
    "main"List_net, "PUSHS bo, funcesult != NO_ER"calling Parser_ParseExpression");
    result = Parser_ParseNestedCode(input, ilist, symtable, nlist);
    if (result != NO_ERROR)
    {
        return result;
    }
    DEBUG_LOG(source,"


//----------------------------d-d-
    //  Zpracování tokenů
   �í pr -----------y-------------------------------------
    char *source = "parser-fix conversion compllis);
 ;los

 d_syult_dNE_END>
  r_getToken(source, input, NULL, LINE_END, NULL);
;
    ifult != NO_ERROR)
    {
        return result;
    }

    //  <FUNCTION>
    result = SCOPEItToken(source, input, NULL, LINE_END, NULL);
;
    ifSCOPEt != NO_RROR)
    {
        return result;
    }

    //  <FUNCTION>
    result = /-------|FIL-----------riableDefinition NULL, LINE_END, NULL);
;
    ifn);
        if (result != NO_ER
    {
        return result;
    }

    //  <FUNCTION>
    resuA)
        {
      FIL-----result;
    }

 m, &token);
            break;
 tění ěn� LINE_END)
    {
        //  Presult;
    }

 ymboT        Token_destroy(&toke   var_  DEBUG_LOG(source, == EQ)dating parameter, eoop");
 ;
    NestingList_leaveERROR)nlist);

   );
    NestingList_debugPrint(nlist);

    return NO_ERROR;
}

int-------------------ion(InputPtr inpu, symtable,tionListPtr ilist, SymbolTablePtr symtable, NestingListPtr nlist)
{= NULL;

    Ne*esult_dt)}
  isnext(paroasul   //  <DI-------   <VARIA = Punc_symb> {+|-|*|/|\|and|or|>|>=|<|<=|<>} <VARIA = Punc_symb> [{+|-|*|/|\|and|or|>|>=|<|<=|<>}]LINE_END>----------------------------------d-d-
    //  Inicializace
    //-----------------------------------------------------
    char *source = "parser-var_def";
    int resuletur TokenPtr ts, &tokeVyčištěn�tr tesult;eVyčišttěn�}
  la   operand_was_lt != NO el!= NO;těn�}
  la   operand_was_opera   Gel!= NO;/---Ji Inknežlzávorky    SymbolPtr cond_sym   SymbolPtr coesultnd_symbol;

    Postf != NOen_Ptr nlevel mbolPSe);
evelPtr nSe);
on"---------------------------------d-d-
    //  Zpracování tokenů
    //-----------------------------------------------------
    Instruction_custom-----esult;eVyči�en_in Symesult_d_ Inseturn SSe);
,"
    Sy= NO_ER
   esult;eVyči�e    return result;
    }

    //  esult;eVyčištN>
    resus, &tokeVyči�ce, input, NULL, LINE_END, NULL);
    ifn);
    if (result != NO_ERROR)ačtení
    }

 
   s, &tokeVyči�c            return result;
        --x;
u donačít------[
/  kteho] operand   DEBUG_ERR(source, "failEQ)datingparse express}
    

returnc,er_ParseNe}

 }

    //  s, &tokeVyčištěn�N>
    resu}

 
          {
        if (resu return result;
        --x;Operand e)iunget
      ult;
        
   ea   operand_was_lt != NO e= urce,ult;
        sult;
            
   nt("INTEGER, STRING, DOUBLEOPERATORput)<EOL>ERROR)
                return INTERNAL_ERROR;
}

    //   }
        return SY_ERROR;
}

    //     break;
    }
    Token_} }
    Token_la   operand_was_lt != NO elurce; }
    Token_la   operand_was_opera   Gel!= NO;
 }
    Token_"creataram->namvar_na NUByevel, I nlist)
{!= NO_ERROR)        
   "createnEBUG_ERR(sou        sult;
            ymboT     Un      id return SYNTAXult;
            datingparse expressuNTAX of ungt, Iedrn result;
    }
  OR;
}

    //   EMAf (C   DEFIN<LINE_  return SY  Token_}zení hodnot    
   "creat  {
      ;
 FUNCLINE)ní hodnot     INTERNAL_ERRORRRRResultnd_sy elud_sym   Sy            ymbo= Ntry ím operandem�en
 iunget
      Resukpresna
  INEvolatResukprult;
            dating parameter, elly parss");
    ch inreturn result;ngult;
            s, &tokeVyči�ce, input, NULL, LINE_END, NULL);
    ifn);
    if (result != NO_E   Sy            _END)
    {
     OPEN_BRACKET)   Sy             INTERNAL_ERRORRRRR    dating parameter, elly parss");
    ch inreturn result;ngTERNAL_ERRORRRRR    ymboT        Token_destngTERNAL_ERRORRRRR       //   EMAf (C   DEFIN<LINE_  retungTERNAL_ERRORRRRR}ngTERNAL_ERRORRRRRdating parameter, eopen b//-ket after lly parss");
    ch,rettr----");
asuletchal_izení hodnot        mbolPSe);
evelPSe);
ce,mbolPSe);
e, func__E   Sy            _r tb//-ketPairsce,0E   Sy            do   Sy             INTERNAL_ERRORRRRR    
          {
      OPEN_BRACKET)   Sy                 INTERNAL_ERRORRRRR        ymboJX očekynvádal�---- dvoji   závorekINTERNAL_ERRORRRRR        b//-ketPairs++;ngTERNAL_ERRORRRRR    }ngTERNAL_ERRORRRRRRRRR LINE_END)
    {
     CLOSE_BRACKET)   Sy                 INTERNAL_ERRORRRRR        ymboUe oč
    dvoji  INTERNAL_ERRORRRRR        b//-ketPairs--;ngTERNAL_ERRORRRRR    }ngTERNAL_ERRORRRRRRRRR LINE_END)
    {
        //  P!||        {
      FIL-----r   Sy                 INTERNAL_ERRORRRRR        ymboTOT      Token_destngTERNAL_ERRORRRRR           //     break;
   INTERNAL_ERRORRRRR        b/eak;ngTERNAL_ERRORRRRR    }ngngTERNAL_ERRORRRRR    mbolPSe);
epush(tSe);
,"!= NO_E   Sy                _ENDb//-ketPairscee,0r   Sy                 INTERNAL_ERRORRRRR        ymboVšechnylzávorky�en
y uzavr_PayINTERNAL_ERRORRRRR        b/eak;ngTERNAL_ERRORRRRR    }gTERNAL_ERRORRRRR    s, &tokeVyči�ce, input, NULL, LINE_END, NULL);
    ifn);
    if (result != NO_E   Sy                _ENDs, &tokeVyči�c               Sy                 INTERNAL_ERRORRRRR           //  s, &tokeVyčišngTERNAL_ERRORRRRR    }ngTERNAL_ERRORRRRR}ngTERNAL_ERRORRRRRLOG(source, ngngTERNAL_ERRORRRRRymboUlož
    nroměnn�ch;
asuletrů_ER"creatuResukprngTERNAL_ERRORRRRRym != NO_Functi2 eluSe);
ongult;
            dating parameter, elly parss
asuls a        Tokeettr---ugPringTERNAL_ERRORRRRRl);

        DEBU"creatO_ERROR)))))))))))))mbolPSe);
e       DEBU Se);
t;ngult;
            ing Parser_ParseExpression"in Symesult_d_addOperandlt;
    }
  OR;
}

 in Symesult_d_addOperandeturn SSe);
,"
    Sy,Resultnd_sy,R"creat,  Se);
t;ult;
            ing Parser_ParseExpeExpression"in Symesult_d_addOperandlt;ngult;
            s, &tokeVyči�ce, input, NULL, LINE_END, NULL);
    ifn);
    if (result != NO_Egult;
            la   operand_was_lt != NO elurce; }
    Token_    la   operand_was_opera   Gel!= NO;
}
    Token_        // ewhile(true)))))}gTERNAL_E}gTERNAL_E LINE_END      isConINGEBU = NO_ e= urce,ult;
    sult;
        --x;Operand e)konINGEBault;
        
   ea   operand_was_lt != NO e= urce,ult;
        sult;
            
   nt("INTEGER, STRING, DOUBLEOPERATORput)<EOL>ERROR)
                return INTERNAL_ERROR;
}

    //   }
        return SY_ERROR;
}

    //     break;
    }
    Token_} }
    Token_la   operand_was_lt != NO elurce; }
    Token_la   operand_was_opera   Gel!= NO;
 }
    Token_"creataram->namvar_na NUByevel, I nlist)
{!= NO_ERROR)    }gTERNAL_E LINE_END      isOpera   U = NO_ e= urce,ult;
    sult;
        --x;Operand e)oper     ult;
        
          {
      OPEN_BRACKET)í hodnot     INTERNAL_ERRORRRRR
   ea   operand_was_lt != NO e= urce,   Sy             NTERNAL_ERRORRRRR    datingparse expressopen b//-ket after lt != NO,  TODO: errorlt;ngTERNAL_ERRORRRRR    ymboT        Token_destngTERNAL_ERRORRRRR       //     break;
   INTERNAL_ERRORRRRR}ngult;
            --x;Oteví    ilzávorka z Tokn-- zaner_Par� dor(sovýrazuult;
            ing Parser_ParseExpression"in Symesult_d_addOperandlt;
    }
  OR;
}

 in Symesult_d_addOperandeturn SSe);
,"
    Sy,ROR)
       ifn NO_ERROR)ROR)        ing Parser_ParseExpeExpression"in Symesult_d_addOperandlt;gult;
            ing Parser_ParseExpression");

    //--Subt = Parser_ParseExxxxxxxxxxxxxesult;eVyči�en_);

    //--Subt = Parser, &postfix, ST_BOOLEAN, &rurn SSe);
,"
    Sy= NO_ER}
  OR;
}

 i   esult;eVyči�e    return resulttttttttttttt NTERNAL_ERRORRRRR    in Symesult_d_cleanupeturn SSe);
,"
    Sy= NO_ERRRRRRRRRRRRRRRRR   //  esult;eVyčištN>
             }gTERNAL_ERRORRRRRrn from Parser_ParseNestedCode");

    //--Sub  PostfixListpodmí������������ymbo= Ntry ím urn Sem  DEBUG_ERuzavr_Pa pr(sovýrazu, nroměmel�---�odmí������������ymbojeho z   DEBUG_LOG(roběhne vlš�tr
 ceí  iliteraciult;
            s, &tokeVyči�ce, input, NULL, LINE_END, NULL);
    ifn);
    if (result != NO_Egult;
            la   operand_was_lt != NO elurce; }
    Token_    la   operand_was_opera   Gel!= NO;
}
    Token_        // ew }
    Token_} }
    Token_ LINE_END)
    {
     CLOSE_BRACKET)í hodnot     INTERNAL_ERRORRRRR
   isnext(paroasul eEB!= NO_ INTER� hodnot     NTERNAL_ERRORRRRR    datingparse express;lose b//-ket in main  parsed");
is  TODO: errorlt;   Sy                _ENDnt("INTEGER, STRING, DOUBLEOPEN_BRACKETput)OPERATORpMAINgRROR)
                return INTERNAL_ERROR;
}

        //   }
        return SY_ERROR;
}

        //     break;
   INTERNAL_ERRORRRRR}ngult;
            ing Parser_ParseExprlose b//-ket in main  parsed");
for lly parss
asuletch, un NU;

 d_sylt;   Sy            t, &token);
            break;
       }
         ing Parser_ParseExp parsed");
is comp   P, oop");
 eak;
        }








b/eak;ngTERNAL_ERROR}ngTERNAL_ERROR LINE_END)
    {
     COMMA)ní hodnot     INTERNAL_ERRORRRRR
   isnext(paroasul eEB!= NO_ INTER� hodnot     INTERNAL_ERRORRRRR    datingparse express;omma in main  parsed");
is  TODO: errorlt;   Sy                _ENDnt("INTEGER, STRING, DOUBLEOPEN_BRACKETput)OPERATORpMAINgRROR)
                returnINTERNAL_ERRORRRRR           //    }
        Symbol_debugRRRR           //     break;
   INTERNAL_ERRORRRRR}ngngTERNAL_ERRORRRRRdating parameter, e;omma in main  parsed");
for lly parss
asuletch, un NU;

 d_sylt;   Sy            t, &token);
            break;
 ngTERNAL_ERRORRRRRdating parameter, e parsed");
is comp   P, oop");
 eak;
        }








b/eak;ngTERNAL_ERROR}gTERNAL_ERROR LINE_ENDla   operand_was_opera   Ge= urce,ult;
        sult;
            datingparse expressopera   Gafter opera   Gis     ionowedlt;
    }
  OR;
}

 �
   aoper     em může býtojedi funoteví    ilzávorkault;
            
   nt("INTEGER, STRING, DOUBLEOPEN_BRACKET    if (resuput)unc_symbERROR)
                return INTERNAL_ERROR;
}

    //   }
        return SY_ERROR;
}

    //     break;
    }
    Token_} }
    Token_la   operand_was_lt != NO el!= NO;
}
    Token_la   operand_was_opera   Gelurce;  }
    Token_"creataraPtr nl  Syken_} }
    ToSymbol byyyyysult;
        --x;Nezš�mý{
ROR)
 u - anikonINGEBa, aniiunget
      Ranioper     ult;
        
   la   operand_was_opera   Ge= urce,ult;
        sult;
            datingparse expressunknown
 d_sy  fter opera   ,  TODO: errorlt;odmí������������ymbo= ce op Ntry í operand�en
 oper     ,Dme
  �R(so Inkvýraz, něco jako:odmí������������ymbovnd"elvnd"+ult;
            
   nt("INTEGER, STRING, DOUBLE  if (resuput)unc_symbERROR)
                return INTERNAL_ERROR;
 NTERNAL_ERRORRRRR    in Symesult_d_cleanupeturn SSe);
,"
    Sy= NO_ERRRRRRRRRRRRRRRRR   //   }
        return SY_ERROR;
}

 }gTERNAL_ERRORRRRR   //     break;
    }
    Token_} ult;
        --x;P Ntry í operand�neen
 oper     ,Dtakže tukvýraz ue oč im  a da Inkurn Sult;
        --x;vr    im  pomo  ils, &toku       Nllykci, kter   si s  im už nějakult;
        --x;    d---------------dating parameter, e parsed");
is comp   P, oop");
 eak;
 -------------t, &token);
            break;
       }
     b/eak;l  Syken_} 
--------dating parameter, esend);
 operand�      Symesult_drlly parsr_U
--------l);

        DEBU"creatO_
--------esult;eVyči�en_in Symesult_d_addOperandeturn SSe);
,"
    Sy,ROR)
   "creat, = NO_ERROR)ROR)
  esult;eVyči�e    return resulttttt{-------------datingparse expression");
   add operand, clean);
 u;
 -------------in Symesult_d_cleanupeturn SSe);
,"
    Sy= NO_ERRRRRRRRR   //  esult;eVyčištN>
     ar <CLOSE_BRACKNroměnn� 
/  ktehoROR)
 u <CLOSE_Bs, &tokeVyči�ce, input, NULL, LINE_END, NULL);
    ifn);
    if (result != NO_ERROR)DEBUG_LOG(source, "

inting Parser_ParseExpression"in Symesult_d_ ro    
 -----mbolPSe);
e       DEBU bolPSe);

 -----= NULL;

  e       DEBU*
    Sy= N
----esult;eVyči�en_in Symesult_d_ ro    eturn SSe);
,"
    Sy= NO_ER
   esult;eVyči�e    return result;
    }

 ed to parse expression");
    ro    return resu, clean);
 u;
 ---------in Symesult_d_cleanupeturn SSe);
,"
    Sy= NO_ERRRRR   //  esult;eVyčištN>
    resudating parameter, e parsed");
 ro    ed !}
    

         ;
}


//--------------------on(InputPtr inpuSub, symtable,tionListPtr ilist, SymbolTablePtr symtable, NestingListPtr nlist)
{mbolPSe);
evel*urn SSe);
,"= NULL;

    Ne*esult_d   //  <DI--------------------------d-d-
    //  Zpracování tokenů
  -------------------------------------------------
    char *source = "parser-cond";
    int result;
  pr_sub TokenPtr ts, &tokeVyčištěn�tr tesult;eVyčišttěn�}
  la   operand_was_lt != NO el!= NO;těn�}
  la   operand_was_opera   Gel!= NO;/---Ji Inknežlzávorky    SymbolPtr cond_sym
----l);

ostf != NOen_Ptr nle//  <DI--------------------------d-d-
    //  Zpracování tokenů
    //-----------------------------------------------------
    Instruction_custom-----s, &tokeVyči�ce, input, NULL, LINE_END, NULL);
    ifn);
    if (result != NO_ERROR)ačtení
    }

 
   s, &tokeVyči�c            return result;
        --x;
u donačít------[
/  kteho] operand   DEBUG_ERR(source, "failEQ)   //  s, &tokeVyčištěn�N>
    resu}

 
          {
         //  Pr return reult;
        
   nt("INTEGER, STRING, DOUBL    ifOR)
                return INTERNAL_ERROR;
   //   }
        return SY_ERROR;
   //     break;
    }
    To}gTERNAL_E LINE_END       {
        if (resu return result;
        --x;Operand e)iunget
      ult;
        
   ea   operand_was_lt != NO e= urce,ult;
        sult;
            
   nt("INTEGER, STRING, DOUBLEOPERATORput)CLOSE_BRACKETERROR)
                return INTERNAL_ERROR;
}

    //   }
        return SY_ERROR;
}

    //     break;
    }
    Token_} }
    Token_la   operand_was_lt != NO elurce; }
    Token_la   operand_was_opera   Gel!= NO;
 }
    Token_"creataram->namvar_na NUByevel, I nlist)
{!= NO_ERROR)        
   "createnEBUG_ERR(sou        sult;
            ymboT     Un      id return SYNTAXult;
               //   EMAf (C   DEFIN<LINE_  return SY  Token_}
RROR)        
   l);

 isVt != NOU"creatO eEB!= NO_ult;
        sult;
            
   "creat  {
      ;
 FUNCLINE) INTERNAL_ERROR;
 NTERNAL_ERRORRRRR    //esult;eVyči�en_);

    //--next(parCess(= NO_ERRRRRRRRRRRRRRRRR   //     break;
    }
    Token_ken_}
}
    Token_ken_Symbol byyyyy_ERROR;
 NTERNAL_ERRORRRRR       //   EMAf (C   OTHERak;
    }
    Token_ken_}
}
    Token_}gTERNAL_E}gTERNAL_E LINE_END      isConINGEBU = NO_ e= urce,ult;
    sult;
        --x;Operand e)konINGEBault;
        
   ea   operand_was_lt != NO e= urce,ult;
        sult;
            
   nt("INTEGER, STRING, DOUBLEOPERATORput)CLOSE_BRACKETERROR)
                return INTERNAL_ERROR;
}

    //   }
        return SY_ERROR;
}

    //     break;
    }
    Token_} }
    Token_la   operand_was_lt != NO elurce; }
    Token_la   operand_was_opera   Gel!= NO;
 }
    Token_"creataram->namvar_na NUByevel, I nlist)
{!= NO_ERROR)        
   "createnEBUG_ERR(sou        sult;
               //   }
        return SY_ERROR;
}gTERNAL_E}gTERNAL_E LINE_END      isOpera   U = NO_ e= urce,ult;
    sult;
        --x;Operand e)oper     ult;
        
          {
      CLOSE_BRACKET)í hodnot     ult;
            ymboJry á INEo ue oč�nn� aktuál--�hol(sovýrazu, v    im     orú resňkvýšult;
            
n Symesult_d_addOperandeurn SSe);
,"
    Sy,ROR)
       ifn NO_ERult;
            dating parameter, esub parsed");
is comp   P, }
    

         ;
}


//               //  ----------Q|LIn->tAL_E}gTERNAL_EAL_E LINE_END       {
      OPEN_BRACKET)í hodnot     ult;
            ymboOteví    ilzávorka z Tokn-- zaner_Par� dor(sovýrazuult;
            
n Symesult_d_addOperandeurn SSe);
,"
    Sy,ROR)
       ifn NO_ERult;
            dating parameter, eression");

    //--Subt = Parser_ParseExxxxxxxxxxxxxesult;eVyči�en_);

    //--Subt = Parser, &postfix, ST_BOOLEAN, &urn SSe);
,"
    Sy= NO_ER}
  OR;
}

 i   esult;eVyči�e    return resulttttttttttttt NTERNAL_ERRORRRRR       //  esult;eVyčištN>
             }gult;
            ymbo= Ntry ím urn Sem  DEBUG_ERuzavr_Pa pr(sovýrazu, nroměmel�---�odmí������������ymbojeho z   DEBUG_LOG(roběhne vlš�tr
 ceí  iliteraciult;
            s, &tokeVyči�ce, input, NULL, LINE_END, NULL);
    ifn);
    if (result != NO_Egult;
            la   operand_was_lt != NO elurce; }
    Token_    la   operand_was_opera   Gel!= NO;
}
    Token_        // ew }
    Token_} }
    Token_ LINE_ENDla   operand_was_opera   Ge= urce,ult;
        sult;
            �
   aoper     em může býtojedi funoteví    ilzávorkault;
            
   nt("INTEGER, STRING, DOUBLEOPEN_BRACKET    if (resuput)unc_symbERROR)
                return INTERNAL_ERROR;
}

    //   }
        return SY_ERROR;
}

    //     break;
    }
    Token_} }
    Token_la   operand_was_lt != NO el!= NO;
}
    Token_la   operand_was_opera   Gelurce;  }
    Token_"creataraPtr nl  Syken_} }
    ToSymbol byyyyysult;
        --x;LL, L e)něco co tu rozhoy funneočekynváme,ult;
        --x;navíc    zdeojedn-- or(sovýraz,Dtakže    zcelannepoR(so urce, "failEQ)ymbojedn-- or TODOktickouRR(souult;
        --x;L        Token_destroy(&toke}

    //     break;
    }
    To}gult;
    esult;eVyči�en_in Symesult_d_addOperandeurn SSe);
,"
    Sy,ROR)
   "creat, = NO_ERROR)ROR)
  esult;eVyči�e    return resulttttt{-------------   //  esult;eVyčištN>
     ar <CLOSE_BRACKNroměnn� 
/  ktehoROR)
 u <CLOSE_Bs, &tokeVyči�ce, input, NULL, LINE_END, NULL);
    ifn);
    if (result != NO_ERROR)DEBUG_LOG(source, "

int------- }
        retur}ti-----------------------------d-d-
//  IFy
//-----------------Pomo ----esukpru--------------------------------
    Instruction_customor-on(InputPtrD     iBuil //next(pars(/*tionListPtr ili t, SymbolTablePtr symtable*/, NestingListPtr nlist))
 INTERNtr token;
 ngngTERNmtablestPtr nnfomngngTERNmtableList_next(parostfesulttion;ngTERNmtableList_next(par_Pasuletch  Nesasul;ngTERNmtableList_next(par_Pasuletch

    Nesasul

  mngng//  <DI--------------------------d-d-
    //  Zpracování tokenů
  Fsukpr ASC-------------------------------------
    Instruction_customngTERNsasul

  Ptr
    PList_next(par_Pasuletch

  e, func__E   Sy
  esuul

  Pt         DEBUNAL_ERROR;
    }

    SymbolInfo_Functi == EQ)pasul er
    PList_next(par_Pasuletche, func_"s"t);
 STRING_E   Sy
  esuulPt         DEBUNAL_ERROR;
    }

    SymbolInfo_Functi =TERNmtableList_next(par_Pasuletch

  ame, varesuul

  ,pasul, ngngTERNpasul er
    PList_next(par_Pasuletche, func_"i"t);
 
   GER_E   Sy
  esuulPt         DEBUNAL_ERROR;
    }

    SymbolInfo_Functi =TERNmtableList_next(par_Pasuletch

  ame, varesuul

  ,pasul, ngngTERNesulttionPtrmtableList_next(par_, func_;
 
   GER,Nsasul

  _E   Sy
  esulttionPt         DEBUNAL_ERROR;
    }

    SymbolInfo_Functi =TERNstedCode(able, var_name, var_type, TEM"asc"t);
 FUNCLINE&func_symbolesulttionif&"creatO_ERROR)
   {
        return r INTERNAL_ERROR;
    }
       //  P�
 =ng//  <DI--------------------------d-d-
    //  Zpracování tokenů
  Fsukpr CHR-------------------------------------
    Instruction_customngTERNsasul

  Ptr
    PList_next(par_Pasuletch

  e, func__E   Sy
  esuul

  Pt         DEBUNAL_ERROR;
    }

    SymbolInfo_Functi == EQ)pasul er
    PList_next(par_Pasuletche, func_"i"t);
 
   GER_E   Sy
  esuulPt         DEBUNAL_ERROR;
    }

    SymbolInfo_Functi =TERNmtableList_next(par_Pasuletch

  ame, varesuul

  ,pasul, ngngTERNesulttionPtrmtableList_next(par_, func_;
 STRING,Nsasul

  _E   Sy
  esulttionPt         DEBUNAL_ERROR;
    }

    SymbolInfo_Functi =TERNstedCode(able, var_name, var_type, TEM"chr"t);
 FUNCLINE&func_symbolesulttionif&"creatO_ERROR)
   {
        return r INTERNAL_ERROR;
    }
       //  P�
 =ng//  <DI--------------------------d-d-
    //  Zpracování tokenů
  Fsukpr LENGTH-------------------------------------
    Instruction_customngTERNsasul

  Ptr
    PList_next(par_Pasuletch

  e, func__E   Sy
  esuul

  Pt         DEBUNAL_ERROR;
    }

    SymbolInfo_Functi == EQ)pasul er
    PList_next(par_Pasuletche, func_"s"t);
 STRING_E   Sy
  esuulPt         DEBUNAL_ERROR;
    }

    SymbolInfo_Functi =TERNmtableList_next(par_Pasuletch

  ame, varesuul

  ,pasul, ngngTERNesulttionPtrmtableList_next(par_, func_;
 
   GER,Nsasul

  _E   Sy
  esulttionPt         DEBUNAL_ERROR;
    }

    SymbolInfo_Functi =TERNstedCode(able, var_name, var_type, TEM"length"t);
 FUNCLINE&func_symbolesulttionif&"creatO_ERROR)
   {
        return r INTERNAL_ERROR;
    }
       //  P�
 =ng//  <DI--------------------------d-d-
    //  Zpracování tokenů
  Fsukpr SUBSTR-------------------------------------
    Instruction_customngTERNsasul

  Ptr
    PList_next(par_Pasuletch

  e, func__E   Sy
  esuul

  Pt         DEBUNAL_ERROR;
    }

    SymbolInfo_Functi == EQ)pasul er
    PList_next(par_Pasuletche, func_"s"t);
 STRING_E   Sy
  esuulPt         DEBUNAL_ERROR;
    }

    SymbolInfo_Functi =TERNmtableList_next(par_Pasuletch

  ame, varesuul

  ,pasul, ngngTERNpasul er
    PList_next(par_Pasuletche, func_"i"t);
 
   GER_E   Sy
  esuulPt         DEBUNAL_ERROR;
    }

    SymbolInfo_Functi =TERNmtableList_next(par_Pasuletch

  ame, varesuul

  ,pasul, ngngTERNpasul er
    PList_next(par_Pasuletche, func_"n"t);
 
   GER_E   Sy
  esuulPt         DEBUNAL_ERROR;
    }

    SymbolInfo_Functi =TERNmtableList_next(par_Pasuletch

  ame, varesuul

  ,pasul, ngngTERNesulttionPtrmtableList_next(par_, func_;
 STRING,Nsasul

  _E   Sy
  esulttionPt         DEBUNAL_ERROR;
    }

    SymbolInfo_Functi =TERNstedCode(able, var_name, var_type, TEM"sub Sy"t);
 FUNCLINE&func_symbolesulttionif&"creatO_ERROR)
   {
        return r INTERNAL_ERROR;
    }
       //  P�
 =ngOR;
    }
---------
}or-on(InputPtrD , IeBuil //next(pars(/*tionListPtr ili */t, SymbolTablePtr symtable, NestingListPtr nlist))
 INTERNtr token;
 ngTERNmtablestPtr nnfomngTERNmtablestPt    vndmngTERNmtablestPtsasul_smngTERNmtablestPtsasul_imngTERN//mtablestPtsasul_n ngngTERNpasul_sde(able, e, func_"s"t);
 STRING, LOC   FRAMEEM"s
       sasul_ide(able, e, func_"i"t);
 STRING, LOC   FRAMEEM"i
       //esuul_nde(able, e, func_"n"t);
 STRING, LOC   FRAMEEM"List_debugPr
   isUsed_ascr INTERNAL_ERROR;�
  Fsukpr ASC e)vG(roguulu použitaAL_ERROR;"creataram->namvar_na NUr_type, TEM"asc"st_dO_ERROR)
  "createnEBUG_ER_dO_ERROR) INTERNAL_ERROR }

   }
        Symbol_debugPriAL_ERROR;
 edCode(list, variabl->key);
    "creat  keyst_dO_ERROR)
        {
            return result;
        }

   }
        Symbol_debugPriAL_ERROR;
 edCode(list, variabse);
epush();
    pasul_sst_dO_ERROR)
        {
            return result;
        }

   }
        Symbol_debugPriAL_ERROR;
 edCode(list, variabse);
epush();
    pasul_ist_dO_ERROR)
        {
            return result;
        }

   }
        Symbol_debugPriAL_ERROR;
 edCode(list, variabseri2tr bse);
 != NO_ERROR)ROR)
        {
            return result;
        }

   }
        Symbol_debugPriAL_ERROR;
 edCode(list, variab
    } != NO_ERROR)ROR)
        {
            return result;
        }

   }
        Symbol_debugPriAL_ERR}_debugPr
   isUsed_chrr INTERNAL_ERROR;�
  Fsukpr CHR e)vG(roguulu použitaAL_ERROR;"creataram->namvar_na NUr_type, TEM"chr"st_dO_ERROR)
  "createnEBUG_ER_dO_ERROR) INTERNAL_ERROR }

   }
        Symbol_debugPriAL_ERROR;
 edCode(list, variabl->key);
    "creat  keyst_dO_ERROR)
        {
            return result;
        }

   }
        Symbol_debugPriAL_ERROR;
 edCode(list, variabse);
epush();
    pasul_ist_dO_ERROR)
        {
            return result;
        }

   }
        Symbol_debugPriAL_ERROR;
 edCode(list, variabtr 2condbse);
 != NO_ERROR)ROR)
        {
            return result;
        }

   }
        Symbol_debugPriAL_ERROR;
 edCode(list, variab
    } != NO_ERROR)ROR)
        {
            return result;
        }

   }
        Symbol_debugPriAL_ERR}_debugPr
   isUsed_lengthr INTERNAL_ERROR;�
  Fsukpr LENGTH e)vG(roguulu použitaAL_ERROR;"creataram->namvar_na NUr_type, TEM"chr"st_dO_ERROR)
  "createnEBUG_ER_dO_ERROR) INTERNAL_ERROR }

   }
        Symbol_debugPriAL_ERROR;    vndaram->namvar_na NUL   Varr_type, TEMymtable,
 
   GER,N0st_dO_ERROR)
      vndarEBUG_ER_dO_ERROR) INTERNAL_ERROR }

   }
        Symbol_debugPriAL_ERROR;
 edCode(list, variabl->key);
    "creat  keyst_dO_ERROR)
        {
            return result;
        }

   }
        Symbol_debugPriAL_ERROR;
 edCode(list, variabserleny);
        vnd  pasul_sst_dO_ERROR)
        {
            return result;
        }

   }
        Symbol_debugPriAL_ERROR;
 edCode(list, variabse);
epush();
        vnd_ERROR)ROR)
        {
            return result;
        }

   }
        Symbol_debugPriAL_ERROR;
 edCode(list, variab
    } != NO_ERROR)ROR)
        {
            return result;
        }

   }
        Symbol_debugPriALmbol_debugm->namvar_na     PL   Varr_type, TEM0YNAL_ERR}_debugPr
   isUsed_sub Syr INTERNAL_ERROR;�
  Fsukpr SUBSTR e)vG(roguulu použitaAL_ERROR;--x;L     Dodělat//  P�
 =ngOR;
    }
---------
}or-on(InputPtr NULL, Ls(cond";
    ii t,onListPtr ili = NestingList_active(n
{mbolPfuncblePtr sexpe--ug_{
  s
{mbolP

    Ne* d_syu   //  <_END     s{
  G_ERR(sourL_ERROR;* d_syuce,mbolP

  e, func__E/  P�
    SymbolPtr cond_sym
----mbolPfuncsexpe--ug_{
  nlevel mbolPfuncbleP_first(expe--ug_{
  s);evel mbolPfuncblePI   stPt unc_i   ce,mbolPfuncbleP_ NUrexpe--ug_{
  s);evel expe--ug_{
  Geluunc_i     {
  nlevel tr ts, &tokeVyči�Definition NULL, LINE_END, NULL);
;
    ifexpe--ug_{
  lt != NO_Egult;
ačtení
    }

  unc_i   ce,mbolPfuncbleP_ NUNexUrexpe--ug_{
  s);evel /  <_END unc_i   ceEBUG_ERR(sou    {-------------   //  ----------Q|LIn->t} }
    ToSxpe--ug_{
  Geluunc_i     {
  nlevel /  <_END     s{
  G_ERR(sou    {-------------mbolP

  eme, var* d_syu
{!= NO_ERROR)    }gTERNAL_E LINR(sou    {-------------mbolPa   Syoy(reak;
       }
 }gTERNAL_Es, &tokeVyči�Definition NULL, LINE_END, NULL);
;
    ifexpe--ug_{
  lt != NO_Eg }
 }gTERNLOG(sos, &tokeVyči�De
           "

int-------s, &tokeVyčišt}r-on(InputPtr NULL, L(cond";
    ii t,onListPtr ili = NestingList_active(n
{mbolPfuncfexpe--ug_{
  ltmbolPtr c* d_sy   //  <#ifdef datingVERBOSE//  <rn from Parser_ParseNqustingLinewl d_sylt;   Sy#end)f   NestingLevelP_dNE_END>
 Nroměnn� OR)
 u zels, &tokuevel tr ts, &tokeVyči�Deft, &tokeG
            bre= NO_ER
    d_sy 
  G_ERR(sourL_ERROR;--x;LL, L seDme
;vr   it přes;
asuletrL_ERROR;* d_syGeluE/  P�
    Sy
     
  G_ERR(sourL_ERROR;--x;Převod klíčového slovalurce al!= NO na�}
 eanovskékonINGEByevel /  <_END   {
      TRUE!||    {
      FALSERR(sou    {-------------   {
    func_symb_BOOLEAN       }
 }L_ERROR;--x;Převod klíčového slovalASC, CHR, LENGTH nebo SUBSTR na�iunget
      ResukprgTERNAL_E LIN<_END   {
      ASC ||    {
      CHR ||    {
      LENGTH ||    {
      SUBSTR   return result;
       _END   {
      ASC)ní hodnot     INTERNAL_ERRORRRRR
sUsed_ascGelurce;INTERNAL_ERROR}ngTERNAL_ERROR LINE_END)  {
      CHR)ní hodnot     INTERNAL_ERRORRRRR
sUsed_chrGelurce;INTERNAL_ERROR}ngTERNAL_ERROR LINE_END)  {
      LENGTH)ní hodnot     INTERNAL_ERRORRRRR
sUsed_lengthGelurce;INTERNAL_ERROR}ngTERNAL_ERROR LINE_END)  {
      SUBSTR   return r     INTERNAL_ERRORRRRR
sUsed_sub SyGelurce;INTERNAL_ERROR}ngTERNAL_ERROR   {
    f  if (resuymbol_debugP/  P�
    Sy
   s, &tokeVyči�c            ||  ceEBUG_E ||    {
      INVALIPresult;
    }

 ymbot, &tok�en
 ue oč�n sRR(so---�m INGv  cnebo vr   ilnneplat Inkurn Su
    }

 ed to parse expresss, &tokt------id returnc,er_ParseNe}

 
   tive(nresulttttt{-------------datingPR  }("\ttive(n: %i\n"t)tive(n->{
  
       }
 }gTERNAL_EdatingPR  }("\tc,er: %i\n\t fuson: %s\n"t)s, &tokeVyči�
{! ?    atSyG: "_ParseNe}

 
   t,ult;
    sult;
        --x;LL, L esme
a�INGli, získ�
  �z nějRR(so--ou z  ávuult;
       _ENDnt("INTEGER, STRING, DOUBLSxpe--ug_{
  G?{mbolPfunc_toStrngLLSxpe--ug_{
  )G:     ifO               return INTERNAL_ERRsult;
            
    d_sy 
  G_ERR(souINTERNAL_ERRsult;
                * d_syGelPtr nl  Syken_     }
 }gTERNAL_EEEEEEEEEmbolPa   Syoy(re
}


//               //   }
        return SY_ERROR;
}gTERNAL_EEEEEmbolPa   Syoy(re
}


//    } }
    ToSymbol byyyyysult;
        --x;LL, L neme
  , předpoklád�
  �(roblém I alok   iult;
        nt("INTEGER, STRionocaaria(
}


//    } evel /  <_END     {
  G_ERR(sou    {-------------* d_syGelPtr nl  Syken_} }
    To   //  s, &tokeVyčištění ěn� LINE_END      Sxpe--ug_{
  G      
    if (resu &&    {
      Sxpe--ug_{
  )esult;
    }

 ymboMá INEe oSyolovat{
ROR)
 u a
 d_sy esme
buď nea�INGli, nebo da Inku
Rnee ehlas iu
    }

 ed to parse expressthisluunc of  d_sy was     Sxpe--ug!_ParseNe}

 datingPR  }("\tSxpe--ug: %i (%s)\n\tgot: %i (%s)\n"ifexpe--ug_{
  ltmbolPfunc_toStrngLLSxpe--ug_{
  ),    {
  ltmbolPfunc_toStrngLL   {
  )ParseNe}

 #ifdef datingVERBOSE//  <EEEEmbolPa       DEBU ParseNe}

 #end)f   Nes/  <_ENDnt("INTEGER, STRING, DOUBLmbolPfunc_toStrngLLSxpe--ug_{
  ),                 return INTERNALeult;
        
    d_sy 
  G_ERR(souINTERNALsult;
            * d_syGelPtr nl  Syken_    }gTERNAL_EEEEEmbolPa   Syoy(re
}


//      To   //   }
        return SY_ERR} evel /  <_END     {
  G_ERR(sou    {-------------* d_syGelPtr nl  Syken_} }
    TombolPa   Syoy(re
}


//       var_  DEBUG_LOG(source, ěn� LINesult;
    }

 ymboZíska Inkurn S e)vG(ořádku
rseNe}

 #ifdef datingVERBOSE//  <EEEE_END      Sxpe--ug_{
  G      
    if (resuRR(souINTERNALdating parameter, esu       Tokereceivid correct
 d_sylt;   Sy    Symbol byyyyy_ERRrn from Parser_ParseNceivid  d_sylt; evel /  <_END     {rEBUG_ER_dO_ERROR) INTERNAL_ERRORrn from Parser_ParsNOT send);
 it back_ParseExxxxxxxxxmbolPa   Syoy(re
}rn SY_ERR} evel /  <mbolPa       DEBU ParseNe}

 #end)f _ERR} evel /*NO_ER
    d_sy 
  G_ERR(sourL_ERROR;* d_syGelPtr nl  Sy}
/  <mbolPa   Syoy(re
}*/

int-------s, &tokeVyčišt}r-on(InputPtrEGER, STRionocaaria(
  //  <retura   cripparss= "Fon");
   aonocaaeDmemory."}


//------- }
        retur}tion(InputPtrEGER, STRungt, Ied(tingLevelPR)
   t,onListPtr il   //  <_n(I iist, variablength NO_ER
    d_sy  {
      INVALIPresult;
    }

 iist, variablengths= 1source, ěn� LINesult;
    }

 iist, variablengths= serleny d_syG?        atSyG: "_ParseNe}level tr t<returaingtxen_in il->cond---ur - iist, variablength NO_ERcond";en_dest;
NO_ER
    d_sy  {
      INVALIPresult;
    }

 ymbotpe-iál--�{
ROR)
 u - obsahujeRR(so--ou z  ávuult;
   en_dest elud_sy  atSysource, ěn� LINesult;
    }

 en_dest elStrngL_p DEBf("UNTAX of ungt, Iedrreference %s rssl Ie %i:%i.ERROR)
   atSy, (cond";)_in il->l Ie, (cond";)_(returaingtxe+ 1), = NO_ERROR)
    Sy
   en_dest e
  G_ERR(sourL_ERROR;-------nt("INTEGER, STRionocaaria(
}


//
    Syretura   cripparsssssssss= en_dest;
  Syreturacondbingtxessssssss= returaingtx;
  Syreturaiist, variablengths= iist, variablength N


//--------------------on(InputPtrEGER, STRio fudyDt, Ied(tingLevelPR)
   t,onListPtr il   //  <_n(I iist, variablength NO_ER
    d_sy  {
      INVALIPresult;
    }

 iist, variablengths= 1source, ěn� LINesult;
    }

 iist, variablengths= serleny d_syG?        atSyG: "_ParseNe}level tr t<returaingtxen_in il->cond---ur - iist, variablength NO_ERcond";en_dest;
NO_ER
    d_sy  {
      INVALIPresult;
    }

 ymbotpe-iál--�{
ROR)
 u - obsahujeRR(so--ou z  ávuult;
   en_dest elud_sy  atSysource, ěn� LINesult;
    }

 en_dest elStrngL_p DEBf("C &to tok      i/ok  , Ie"creata%s rssl Ie %i:%i.ERROR)
   atSy, (cond";)_in il->l Ie, (cond";)_(returaingtxe+ 1), = NO_ERROR)
    Sy
   en_dest e
  G_ERR(sourL_ERROR;-------nt("INTEGER, STRionocaaria(
}


//
    Syretura   cripparsssssssss= en_dest;
  Syreturacondbingtxessssssss= returaingtx;
  Syreturaiist, variablengths= iist, variablength N


//--------------------on(InputPtrEGER, STRING, DOUBLcond";Sxpe--ugltmbolPtr cPR)
   t,onListPtr il   //  <_n(I iist, variablength NO_ER
    d_sy  {
      INVALIPresult;
    }

 iist, variablengths= 1source, ěn� LINesult;
    }

 iist, variablengths= serleny d_sy  atSyG?        atSyG: "_ParseNe}level tr t<returaingtxen_in il->cond---ur - iist, variablength NO_ERcond";en_dest;
NO_ER
    d_sy  {
      INVALIPresult;
    }

 ymbotpe-iál--�{
ROR)
 u - obsahujeRR(so--ou z  ávuult;
   en_dest elud_sy  atSysource, ěn� LINR
   Sxpe--ug 
  G_ERR(sourL_ERROR;--x;OčekynvGli esme
něco e okrét--�ho
    }

 en_dest elStrngL_p DEBf("UnSxpe--ug ING, DOUB rssl Ie %i:%i. Expe--ug %s got %s.ERR(cond";)_in il->l Ie, (cond";)_(returaingtxe+ 1), Sxpe--ugltmbolPfunc_toStrngLL d_sy  {
  ))source, ěn� LINesult;
    }

 --x;Buď esme
toho očekynvGli spoustu, jako vždy,
    }

 --x;nebo esme
toho naopak mocnneočekynvGli
    }

 en_dest elStrngL_p DEBf("UnSxpe--ug %s rssl Ie %i:%i.ERRmbolPfunc_toStrngLL d_sy  {
  ), (cond";)_in il->l Ie, (cond";)_(returaingtxe+ 1), = NO_ERROR)
    Sy
   en_dest e
  G_ERR(sourL_ERROR;-------nt("INTEGER, STRionocaaria(
}


//
    Syretura   cripparsssssssss= en_dest;
  Syreturacondbingtxessssssss= returaingtx;
  Syreturaiist, variablengths= iist, variablength N


//--------------------on(InputPtrEGER, STRcustom(cond";    OUB
  //  <retura   cripparsssssssss=     OUB;
  Syreturacondbingtxessssssss= -1;
  Syreturaiist, variablengths= -1;
  Sy----